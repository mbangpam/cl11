# -*- coding: utf-8 -*-
#KONTOL KONTOL KONTOL
#PUSING NI PALA BABI
'''
INI NAMANYA CL KONTOL

IYUS
'''
from important import *
import youtube_dl
import requests
import humanize
import html5lib
from gtts import gTTS
from bs4 import BeautifulSoup
import requests, json
import urllib, urllib3, urllib.parse
import pytz, datetime, time, timeit, livejson,asyncio, random, sys, ast, re, os, json, subprocess, threading, string, codecs, requests, ctypes, urllib, traceback, tempfile, platform
from thrift import transport, protocol, server
from thrift.Thrift import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from gtts import gTTS
from datetime import timedelta, date
from datetime import datetime
from threading import Thread, activeCount
from googletrans import Translator
from Naked.toolshed.shell import execute_js
parser = argparse.ArgumentParser(description='COBA DOANG')
parser.add_argument('-t', '--token', type=str, metavar='', required=False, help='Token | Example : Exxxx')
parser.add_argument('-e', '--email', type=str, default='', metavar='', required=False, help='Email Address | Example : example@xxx.xx')
parser.add_argument('-p', '--password', type=str, default='', metavar='', required=False, help='Password | Example : xxxx')
parser.add_argument('-a', '--apptype', type=str, default='', metavar='', required=False, choices=list(ApplicationType._NAMES_TO_VALUES), help='Application Type | Example : CHROMEOS')
parser.add_argument('-s', '--systemname', type=str, default='', metavar='', required=False, help='System Name | Example : Chrome_OS')
parser.add_argument('-c', '--channelid', type=str, default='', metavar='', required=False, help='Channel ID | Example : 1341209950')
parser.add_argument('-T', '--traceback', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Using Traceback | Use : True/False')
parser.add_argument('-S', '--showqr', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Show QR | Use : True/False')
args = parser.parse_args()
listAppType = ['DESKTOPWIN', 'DESKTOPMAC', 'IOSIPAD', 'CHROMEOS']
#===============LINE SEMAKIN GJLS MEMEK========
#============INI NAMA NYA CL KONTOL============
#============CODING CREATOR IYUS===============
#===============LINE KONTOL LINE KONTOL========
settings = livejson.File('setting1.json', True, False, 4)
email = settings["email"]
password = settings["password"]
appName = settings["appName"]
owner = settings["owner"]
admin = settings["admin"]
programStart = time.time()
line = LINE(email,password)
myMid = line.profile.mid
oepoll = OEPoll(line)
protectinvite = []
protectkick = []
protectjoin = []
protectqr = []
protectcancel = []
tmp_text = []
lurking = {}
#ban = livejson.File('blacklist.json', True, False, 4)
silent = livejson.File('silent.json', True, False, 4)
tagmeOpen = codecs.open("tag.json","r","utf-8")

tagme = json.load(tagmeOpen)
lastseen = ({
    "find": {},
    "username": {}
})
cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
tailah = {
    "siderTemp": {},
    "siderPesan": "sider terus, sini nimbrung dong",
}
gwcool = {
    "squad": "SELFTCR™",
}
joinpurge = {
    "purgee": False,
    "purgebl": True,
}
seni = {
    "cleave": "bye",
    "ckill": "kill",
    "cinv": "sini"
}
nukemode = {
    "java": False,
    "kickstk": False,
    "invitestk": False,
    "kickID": "",
    "kickVER": "",
    "kckgID": "",
    "invID": "",
    "invVER": "",
    "invtID": ""
}
read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}
wait = {
    "limit": 2,
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "selfbot": True,
    "notifcall": False,
    "selfbot1": False,
    "lang":"JP",
    "Timeline": False,
    "Mentiongift": False,
    "wteam": False,
    "dteam": False,
    "wblacklist": False,
    "dblacklist": False,
    "wwhitelist": False,
    "dwhitelist": False,
}
liffV1 = {
    "arLiff": True
}
bool_dict = {
    True: ['Yes', 'Active', 'Success', 'Open', 'On'],
    False: ['No', 'Not Active', 'Failed', 'Close', 'Off']
}
profile = line.getContact(myMid)
settings['myProfile']['displayName'] = profile.displayName
settings['myProfile']['statusMessage'] = profile.statusMessage
settings['myProfile']['pictureStatus'] = profile.pictureStatus
coverId = line.profileDetail['result']['objectId']
settings['myProfile']['coverId'] = coverId
if not settings:
    print ('##----- LOAD DEFAULT JSON -----##')
    try:
        default_settings = line.server.getJson('https://17hosting.id/default.json')
        settings.update(default_settings)
        print ('##----- LOAD DEFAULT JSON (Success) -----##')
    except Exception:
        print ('##----- LOAD DEFAULT JSON (Failed) -----##')
def restartProgram():
    print ('##----- PROGRAM RESTARTED -----##')
    python = sys.executable
    os.execl(python, python, *sys.argv)
def logError(error, write=True):
    errid = str(random.randint(100, 999))
    filee = open('tmp/errors/%s.txt'%errid, 'w') if write else None
    if args.traceback: traceback.print_tb(error.__traceback__)
    if write:
        traceback.print_tb(error.__traceback__, file=filee)
        filee.close()
        with open('errorLog.txt', 'a') as e:
            e.write('\n%s : %s'%(errid, str(error)))
    print ('++ Error : {error}'.format(error=error))
def removeCmd2(cmd, text):
	key = settings['setKey']['key']
	if settings['setKey']['status'] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def removeCmd(text, key=''):
    if key == '':
        setKey = '' if not settings['setKey']['status'] else settings['setKey']['key']
    else:
        setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(' ')
    return text_[len(sep[0] + ' '):]
def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False
def replaceAll(text, dic):
    try:
        rep_this = dic.items()
    except:
        rep_this = dic.iteritems()
    for i, j in rep_this:
        text = text.replace(i, j)
    return text
def command(text):
    pesan = text.lower()
    if settings['setKey']['status']:
        if pesan.startswith(settings['setKey']['key']):
            cmd = pesan.replace(settings['setKey']['key'],'')
        else:
            cmd = 'Undefined command'
    else:
        cmd = text.lower()
    return cmd
def genImageB64(path):
    with open(path, 'rb') as img_file:
        encode_str = img_file.read()
        b64img = base64.b64encode(encode_str)
        return b64img.decode('utf-8')
def kick(group, target):
    try:
        line.kickoutFromGroup(group, [target])
        if target == op.param2:
            line.kickoutFromGroup(group, [target])
    except:
        pass

def cancel(group, target):
    try:
        line.cancelGroupInvitation(group, [target])
        if target == op.param2:
            line.cancelGroupInvitation(group, [target])
    except:
        pass

def invite(grup, target):
    try:
        line.findAndAddContactsByMid(target)
        line.inviteIntoGroup(grup, [target])
    except:pass
    print("NOTIF_INVITE_")

def join(group):
    try:
        line.acceptGroupInvitation(group)
    except:
        try:
            line.acceptGroupInvitation(group)
        except:
            pass

def lockqr(group):
    try:
        G = line.getGroup(group)
        G.preventedJoinByTicket = True
        asd = line.updateGroup(G)
        if asd != None:
            hlthfail
    except:
        try:
            G = line.getGroup(group)
            G.preventedJoinByTicket = True
            asd = line.updateGroup(G)
            if asd != None:
                hlthfail
        except:
            pass

def backup(group, target):
    try:
        line.inviteIntoGroup(group, [target])
        if target == op.param3:
            line.inviteIntoGroup(group, [target])
    except:
        try:
            line.inviteIntoGroup(group, [target])
            if target == settings["whitelist"]:
                line.inviteIntoGroup(group, [target])
        except:
            pass

def blacklist(target):
    if target not in admin or target not in settings["whitelist"] or target not in owner:
        settings["blacklist"].append(target)
def allowLiff3(): #LIFF TROJAN
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1638870522',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def allowLiff2(): #LIFF EATER
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1586794970',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)         
def allowLiff(): #LIFF AR
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1602687308',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def sendTemplate(to, data):
    allowLiff()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    if liffV1["arLiff"]: view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    else: view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
    
def sendTemplate3(to, data):
    allowLiff3()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1638870522-PnjreV13', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate2(to, data):
    allowLiff2()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def changeProfileVideo(to):
    if settings['changeProfileVideo']['picture'] == None:
        return line.sendMessage(to,"「 Picture Not Found♪ 」")
    elif settings['changeProfileVideo']['video'] == None:
        return line.sendMessage(to,"「 Video Not Found♪ 」")
    else:
        path = settings['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = line.genOBSParams({'oid': line.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return line.sendMessage(to,"「 Fail Update Profile♪ 」")
        path_p = settings['changeProfileVideo']['picture']
        settings['changeProfileVideo']['status'] = False
        line.updateProfilePicture(path_p, 'vp')
def changevideopp(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = line.genOBSParams({'oid': myMid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'Hello_World.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        line.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))
def genUrlB64(url):
    return base64.b64encode(url.encode('utf-8')).decode('utf-8')
def removeCmd(text, key=''):
    if key == '':
        setKey = '' if not settings['setKey']['status'] else settings['setKey']['key']
    else:
        setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(' ')
    return text_[len(sep[0] + ' '):]
def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False
def replaceAll(text, dic):
    try:
        rep_this = dic.items()
    except:
        rep_this = dic.iteritems()
    for i, j in rep_this:
        text = text.replace(i, j)
    return text
def parsingRes(res):
    result = ''
    textt = res.split('\n')
    for text in textt:
        if True not in [text.startswith(s) for s in ['╭', '║✈︎', '│', '╰']]:
            result += '\n│ ' + text
        else:
            if text == textt[0]:
                result += text
            else:
                result += '\n' + text
    return result
def sendMention1(to, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    result = '* Mention Members *\n\n'
    mention = '@botmudebot\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '  • %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '\n* Mention Members *\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def mentionMembers2(gid, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    G = line.getGroup(gid)
    result = '╭─── [ Mentions ] ─\n'
    mention = '@botmudebot\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '├ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰───[ Members ]\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(gid, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def sendMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@botmudebot "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendReplyMessage(msg.id,to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def sendMention2(msg_id, to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@botmudebot "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def cloneProfile(mid):
    contact = line.getContact(mid)
    profile = line.getProfile()
    profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
    line.updateProfile(profile)
    if contact.pictureStatus:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus)
        line.updateProfilePicture(pict)
    coverId = line.getProfileDetail(mid)['result']['objectId']
    line.updateProfileCoverById(coverId)
def backupProfile():
    profile = line.getContact(myMid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    coverId = line.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
def debug():
    get_profile_time_start = time.time()
    get_profile = line.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_profile_took = time.time() - get_profile_time_start
    return "「 Speed 」\n • Took : %.3fms♪\n • Taken: %.5f♪" % (get_profile_took,get_profile_time)
def restoreProfile():
    profile = line.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    line.updateProfile(profile)
    if settings['myProfile']['pictureStatus']:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'])
        line.updateProfilePicture(pict)
    coverId = settings['myProfile']['coverId']
    line.updateProfileCoverById(coverId)
def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
    if cmd == 'mute':
      if msg._from in owner or msg._from in admin:
        if to in silent['silent']:
            line.sendMessage(to, 'you have to Mute this group\nPlease Usage Commands "unmute" ')
        else:
            silent['silent'].append(to)
            line.sendMessage(to, 'Bot cant Not Operation again♪')
    elif cmd == 'unmute':
      if msg._from in owner or msg._from in admin:
        if to not in silent['silent']:
            line.sendMessage(to, "you haven't  this group :)")
        else:
            silent['silent'].remove(to)
            line.sendMessage(to, 'Bot can Operation again♪')
    if to in silent['silent']:
        return
    if cmd == 'logout':
      if msg._from in owner or msg._from in admin:
        line.sendMessage(to, 'Selfbot will logged out')
        sys.exit('##----- PROGRAM STOPPED -----##')
    elif cmd == 'logoutdevicee':
      if msg._from in owner or msg._from in admin:
        line.logout()
        sys.exit('##----- CLIENT LOGOUT -----##')
    elif cmd == 'restart':
      if msg._from in owner or msg._from in admin:
        line.sendMessage(to, 'Bot will restarting, please wait until the bot can operate ♪')
        settings['restartPoint'] = to
        restartProgram()
#================Menu Help================
    elif cmd.startswith('help'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = "╭───「Help Command」"
        res += "\n├⌬ {key}Profile"
        res += "\n├⌬ {key}custom"
        res += "\n├⌬ {key}Group"
        res += "\n├⌬ {key}Self"
        res += "\n├⌬ {key}Protection"
        res += "\n├⌬ {key}Speed"
        res += "\n├⌬ {key}Runtime"
        res += "\n├⌬ {key}Setting"
        res += "\n├⌬ {key}Status"
        res += "\n├⌬ {key}Spam"
        res += "\n├⌬ {key}Team"
        res += "\n├⌬ {key}Cekbot"
        res += "\n├⌬ {key}Js"
        res += "\n├⌬ {key}Bye"
        res += "\n├⌬ {key}Uns「Num」"
        res += "\n├⌬ {key}Kibar"
        res += "\n├⌬ {key}Kibar1"
        res += "\n├⌬ Rname"
        res += "\n├⌬ Respon"
        res += "\n╰───「 Help Command 」"
        if cmd == 'help':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
            
    elif cmd.startswith('custom'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = "╭───「Change Command」"
        res += "\n├⌬ {key}Changekickr:「Text」"
        res += "\n├⌬ {key}Changeinvites:「Text」"
        res += "\n├⌬ {key}changekickall:「Text」"
        res += "\n├⌬ {key}changecancelall:「Text」"
        res += "\n├⌬ {key}Changebypass:「Text」"
        res += "\n├⌬ {key}Changetagall:「Text」"
        res += "\n├⌬ {key}Changekill:「Text」"
        res += "\n├⌬ {key}Changeinvname:「Text」"
        res += "\n├⌬ {key}Changeleave:「Text」"
        res += "\n├⌬ {key}Changekick:「Text」"
        res += "\n├⌬ {key}Changerespon:「Text」"
        res += "\n├⌬ {key}Changername:「Text」"
        res += "\n├───「Status Command」"
        res += "\n├⌬ {key}%s「KickReply」" % settings["changekickr"]
        res += "\n├⌬ {key}%s「InviteReply」" % settings["changeinvites"]
        res += "\n├⌬ {key}%s「Kickall」" % settings["changekickall"]
        res += "\n├⌬ {key}%s「Cancelall」" % settings["changecancelall"]
        res += "\n├⌬ {key}%s「Bypass」" % settings["changebypass"]
        res += "\n├⌬ {key}%s「Tagall」" % settings["changetagall"]
        res += "\n├⌬ {key}%s「@/Name」" % seni["ckill"]
        res += "\n├⌬ {key}%s「@/Name」" % seni["cinv"]
        res += "\n├⌬ {key}%s「leavegroup」" % seni["cleave"]
        res += "\n├⌬ {key}%s「mention」" % settings["changekick"]
        res += '\n├⌬ {key}invite「Mention」'
        res += '\n├⌬ {key}kickjs「Mention」'
        res += '\n├⌬ {key}slain「Mention」'
        res += "\n├⌬ Response: %s" % settings["respon"]
        res += "\n╰───「 Change Command 」"
        if cmd == 'custom':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
            
    elif cmd.startswith('profile'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = "╭───「Help Command」"
        res += "\n├⌬ {key}Changename「Text」"
        res += "\n├⌬ {key}Changebio「Text」"
        res += "\n├⌬ {key}Changevp"
        res += "\n├⌬ {key}Changepict"
        res += "\n├⌬ {key}Changecover"
        res += "\n├───「S E T」"
        res += "\n├⌬Rname"
        res += "\n├⌬Uprname:「Text」"
        res += "\n╰───「 Help Command 」"
        if cmd == 'profile':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))

    elif cmd.startswith('js'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = "╭───「Type: JS♪」"
        res += "\n├⌬•  「 Status 」\n\n"
        if nukemode["java"] == "":res += "  JavaMode : OFF\n"
        else:res += "  JavaMode : {}\n".format(str(nukemode["java"]))
        res += "\n├⌬ {key}%s「 Bypass 」" % settings["changebypass"]
        res += "\n├⌬ {key}%s「 Kickall 」" % settings["changekickall"]
        res += "\n├⌬ {key}%s「 Cancelall 」" % settings["changecancelall"]
        res += "\n├⌬ {key}javamode「 On/Off 」"
        res += "\n├⌬• Type: Remote Js♪"
        res += "\n├⌬ {key}meluncur:「 Num 」"
        res += "\n├⌬ {key}kickall:「 Num 」"
        res += "\n├⌬ {key}cancelall:「 Num 」"
        res += "\n╰───「Type: JS♪」"
        if cmd == 'js':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
        
        
    elif cmd.startswith('group'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '╭───「Help Group」'
        res += '\n├⌬ {key}Getname「Mention」'
        res += '\n├⌬ {key}Getbio「Mention」'
        res += '\n├⌬ {key}Getcover「Mention」'
        res += '\n├⌬ {key}Getvideo「Mention」'
        res += '\n├⌬ {key}Getmid「Mention」'
        res += '\n├⌬ {key}Getprofile「Mention」'
        res += '\n├⌬ {key}%s'  % settings["changetagall"]
        res += '\n├⌬ {key}Ginfo'
        res += '\n├⌬ {key}infomem'
        res += '\n├⌬ {key}Glist'
        res += '\n├⌬ {key}Gpending'
        res += '\n├⌬ {key}Openqr'
        res += '\n├⌬ {key}Closeqr'
        res += '\n╰───「 Help Group 」'
        if cmd == 'group':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))

    elif cmd.startswith('spam'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '╭───「Help spam」'
        res += '\n├⌬ {key}spamtag 「Num」「Tag」'
        res += '\n├⌬ {key}Spamcall 「Num」'
        res += '\n╰───「 Help spam 」'
        if cmd == 'spam':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('team'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = "• Type: Help Team "
        res += "\n › {key}teamlist"
        res += "\n › {key}clearteam"
        res += "\n › {key}addteam「 @ 」"
        res += "\n › {key}delteam「 @ 」"
        res += "\n › {key}team「 on 」"
        res += "\n › {key}team「 off 」"
        res += "\n › {key}changeteam:「 Text 」"
        res += "\n › {key}%s「 Command For Invite Team 」" % settings["changeteam"]
        if cmd == 'team':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
            
    elif cmd.startswith('protection'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '╭───「Help Protect」'
        res += '\n├⌬ {key}Protectlist'
        res += '\n├⌬ {key}Setpro'
        res += '\n├⌬ {key}Prokick「On/Off」'
        res += '\n├⌬ {key}Proinvite「On/Off」'
        res += '\n├⌬ {key}Projoin「On/Off」'
        res += '\n├⌬ {key}Procancel「On/Off」'
        res += '\n├⌬ {key}Proqr「On/Off」'
        res += '\n├⌬ {key}Allpro「On/Off」'
        res += '\n╰───「 Help Protect 」'
        if cmd == 'protection':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
 
    elif cmd.startswith('setting'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '╭───「Help setting」'
        res += '\n├⌬ {key}Greet'
        res += '\n├⌬ {key}Lurk'
        res += '\n├⌬ {key}Ajs「On/Off」'
        res += '\n├⌬ {key}Notifcall「On/Off」'
        res += '\n├⌬ {key}Sider「On/Off」'
        res += '\n├⌬ {key}Sider1「On/Off」'
        res += '\n├⌬ {key}AutoAdd「On/Off」'
        res += '\n├⌬ {key}Respongift「On/Off」'
        res += '\n├⌬ {key}Autorespon「On/Off」'
        res += '\n├⌬ {key}Autorespondmention「On/Off」'
        res += '\n├⌬ {key}Autoread「On/Off」'
        res += '\n├⌬ {key}Autojoin「On/Off」'
        res += '\n├⌬ {key}Autojoin ticket「On/Off」'
        res += '\n├⌬ {key}Warmode「On/Off」'
        res += '\n├⌬ {key}Joinpurge「On/Off」'
        res += '\n├⌬ {key}Antitag「On/Off」'
        res += '\n├⌬ {key}Detectpost「On/Off」'
        res += '\n├⌬ {key}Checksticker「On/Off」'
        res += '\n├⌬ {key}Checkcontact「On/Off」'
        res += '\n├⌬ {key}Resendchat「On/Off」'
        res += '\n╰───「Help setting」'
        if cmd == 'setting':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
            
    elif cmd.startswith('self'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '╭───「Blacklist」'
        res += '\n├⌬ {key}Blacklist'
        res += '\n├⌬ {key}Clearbl'
        res += '\n├⌬ {key}Cek bl'
        res += '\n├⌬ {key}Addbl「Mention」'
        res += '\n├⌬ {key}Delbl「Mention」'
        res += '\n├⌬ {key}Bl「On/Off」'
        res += '\n├⌬ {key}Delbl:「Num」'
        res += '\n├⌬ {key}Purge'
        res += '\n├⌬ {key}Purgejs'
        res += '\n├───「Whitelist」'
        res += '\n├⌬ {key}Whitelist'
        res += '\n├⌬ {key}Clearwl'
        res += '\n├⌬ {key}Cek wl'
        res += '\n├⌬ {key}Addwl「Mention」'
        res += '\n├⌬ {key}Delwl「Mention」'
        res += '\n├⌬ {key}Wl「On/Off」'
        res += '\n├⌬ {key}Delwl:「Num」'
        res += '\n├───「Admin」'
        res += '\n├⌬ {key}Adminlist'
        res += '\n├⌬ {key}Clearadmin'
        res += '\n├⌬ {key}Addadmin「Mention」'
        res += '\n├⌬ {key}Deladmin「Mention」'
        res += '\n├⌬ {key}Admin「On/Off」'
        res += '\n├⌬ {key}Deladmin:「Num」'
        res += '\n├───「Botlist」'
        res += '\n├⌬ {key}Addbot「Mention」'
        res += '\n├⌬ {key}Delbot「Mention」'
        res += '\n├⌬ {key}Botlist'
        res += '\n╰───「 Self 」'
        if cmd == 'self':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
#================BATAS================
    elif cmd == 'status':
      if msg._from in owner or msg._from in admin:
        res = '╭───「Status」'
        res += '\n├⌬ Auto Like : ' + bool_dict[settings['autolike']['status']][1]
        res += '\n├⌬ Auto Comment : ' + bool_dict[settings['autokomen']['status']][1]
        res += '\n├⌬ Auto Add : ' + bool_dict[settings['autoAdd']['status']][1]
        res += '\n├⌬ Auto Join : ' + bool_dict[settings['autoJoin']['status']][1]
        res += '\n├⌬ AutoJoin ticket : ' + bool_dict[settings['autoJoin']['ticket']][1]
        res += '\n├⌬ JoinPurge : ' + bool_dict[joinpurge['purgee']][1]
        res += '\n├⌬ Warmode : ' + bool_dict[joinpurge['purgebl']][1]
        res += '\n├⌬ Auto Respond : ' + bool_dict[settings['autoRespond']['status']][1]
        res += '\n├⌬ Auto Respond Mention : ' + bool_dict[settings['autoRespondMention']['status']][1]
        res += '\n├⌬ Auto Read : ' + bool_dict[settings['autoRead']][1]
        res += '\n├⌬ Setting Key : ' + bool_dict[settings['setKey']['status']][1]
        res += '\n├⌬ Mention Kick : ' + bool_dict[settings['mentionkick']][1]
        res += '\n├⌬ Check Contact : ' + bool_dict[settings['checkContact']][1]
        res += '\n├⌬ Detectpost : ' + bool_dict[wait['Timeline']][1]
        res += '\n├⌬ Check Sticker : ' + bool_dict[settings['checkSticker']][1]
        res += '\n├⌬ Status Ajs : ' + bool_dict[wait['selfbot1']][1]
        res += '\n├⌬ Notifcall : ' + bool_dict[wait['notifcall']][1]
        res += '\n├⌬ Respongift : ' + bool_dict[wait['Mentiongift']][1]
        res += '\n├⌬ Resendchat : ' + bool_dict[settings['unsendMessage']][1]
        res += '\n├⌬ Greetings Join : ' + bool_dict[settings['greet']['join']['status']][1]
        res += '\n├⌬ Greetings Leave : ' + bool_dict[settings['greet']['leave']['status']][1]
        res += '\n╰───「Status」'
        line.sendMessage(to,res)
    elif cmd == 'speed':
      if msg._from in owner or msg._from in admin:
            debugs = debug()
            line.sendMessage(to, debugs)
    elif cmd == "me" or text.lower() == ' me':
      if settings["selfbot"] == True:
        if msg._from in owner or msg._from in admin:
           msg.contentType = 13
           msg.contentMetadata = {'mid': msg._from}
           line.sendMessage(to, None, contentMetadata={'mid': msg._from}, contentType=13)     
    elif cmd == 'bot':
      if msg._from in owner or msg._from in admin:
        line.sendMessageMusic(to, title=line.getContact(myMid).displayName, subText=str(line.getContact(myMid).statusMessage), url='https://line.me/ti/p/yWhS9D2xpT', iconurl="http://dl.profile.line-cdn.net/{}".format(line.getContact(myMid).pictureStatus), contentMetadata={})
    elif cmd == 'runtime':
      if msg._from in owner or msg._from in admin:
        runtime = time.time() - programStart
        line.sendMessage(to, ' Bot already running on ' + format_timespan(runtime))
    elif cmd == 'kibar1':
      if msg._from in owner or msg._from in admin:
        line.sendMessage(to,"🐉ⒶⓈⓈⒶⓁⒶⓂⓊⒶⓁⒶⒾⓀⓊⓂ🐉")
        line.sendMessage(to,"🐉ⒹⒶⓇ ⒹⒺⓇ ⒹⓄⓇ🐉\n"
"  ╭━Ⓓ✒Ⓡ✒Ⓐ✒Ⓖ✒Ⓞ✒Ⓝ✒\n"
"  ╰╮┏━┳┳┓┏┳┳┓┏┳┳┳┓\n"
"  ┏┻╋━┻┻┫┣┻┻┫┣┻┻┻┫\n"
"  ┃HALO▪┃KAMI DTANG LAGI┃\n"
"  ┗ⓞⓞ┻┻ⓞ━━ⓞ┻┻ⓞ━╯\n"
"UNTUK MENGGUSUR ROOM KALIAN\n"
"(҂`_´҂)\n"
   " <,︻╦̵̵̿╤━ ҉     ~  •\n"
"█۞███████]▄▄▄▄▄▄▃●●\n"
"▂▄▅█████████▅▄▃▂…\n"
"[██████████████████]\n"
"◥⊙⊙▲⊙▲⊙▲⊙▲⊙▲⊙\n"
"╭━╮╭━╮\n"
"┃┃╰╯┃┃\n"
"┃╭╮╭╮┣┳━╮╭━━┳━━┳┳━╮\n"
"┃┃┃┃┃┣┫╭╮┫╭╮┃╭╮┣┫╭╯\n"
"┃┃┃┃┃┃┃┃┃┃╰╯┃╰╯┃┃┃\n"
"╰╯╰╯╰┻┻╯╰┻━╮┣━╮┣┻╯\n"
"╱╱╱╱╱╱╱╱╱╭━╯┣━╯┃\n"
"╱╱╱╱╱╱╱╱╱╰━━┻━━╯\n"
"🐉━━━━━━━━━━━━━🐉"
"ⓉⒶⓂⓅⒶ ⒷⒶⓈⒶ ⒷⒶⓈⒾ\n"
"ⓇⒶⓉⒶ ⒼⒶ ⓇⒶⓉⒶ\n" 
"ⓎⒶⓃⒼ ⓅⒺⓃⓉⒾⓃⒼ ⓀⒾⒷⒶⓇ\n"
"ⒼⒶⓁⓇⒶⓉ ⓈⓁⓄⓌ\n"
"ⓂⒶⓈⒾⒽ ⒶⒹⒶ ⒽⒶⓇⒾ ⓁⒶⒾⓃ\n"
"ⓉⒶⓃⒼⓀⒾⓈ ⒼⓄⒷⓁⓄⓀ\n"
"🐉━━━━━━━━━━━━━🐉\n"
	"╔══╗╔═╗╔══╗╔═╦═╗\n"
	"╚╗╔╝║╦╝║╔╗║║║║║║\n"
	"━║║━║╩╗║╠╣║║║║║║\n"
	"━╚╝━╚═╝╚╝╚╝╚╩═╩╝\n"
"🐉━━━━━━━━━━━━━🐉\n"
	"╔══╗         ╔╦╗\n"
	"╚╗╗║         ║╔╝\n"
	"╔╩╝║         ║╚╗\n"
	"╚══╝         ╚╩╝\n"
"🐉━━━━━━━━━━━━━🐉\n"        
"ⒹⓇⒶⒼⓄⓃ ⓀⒾⓁⒺⓇ\n"
"ⓅⓊⓃⓎⒶ🐉━━🐉ⓇⒶⓉⒶ ⓃⒾ\n" 
"ⓂⒶⒽ━🐉━\n"
		"╔═╗╔══╗╔══╗╔══╗\n"
		"║╬║║╔╗║╚╗╔╝║╔╗║\n"
		"║╗╣║╠╣║━║║━║╠╣║\n"
		"╚╩╝╚╝╚╝━╚╝━╚╝╚╝\n"
		"━━━━━━━━━━━━━━━\n"
		"╔═╗╔══╗╔══╗╔══╗\n"
		"║╬║║╔╗║╚╗╔╝║╔╗║\n"
		"║╗╣║╠╣║━║║━║╠╣║\n"
		"╚╩╝╚╝╚╝━╚╝━╚╝╚╝\n"
		"━━━━━━━━━━━━━━━\n"
		"╔═╗╔══╗╔══╗╔══╗\n"
		"║╬║║╔╗║╚╗╔╝║╔╗║\n"
		"║╗╣║╠╣║━║║━║╠╣║\n"
		"╚╩╝╚╝╚╝━╚╝━╚╝╚╝\n"
		"━━━━━━━━━━━━━━━\n"
"🐉ⒷⓎⒺ ⒷⓎⒺ ⒼⒸ ⓁⒶⓀⓃⒶⓉ🐉\nⒹⒺⓃⒹⒶⓂ ⒸⒶⓇⒾ ⓀⒶⓂⒾ🐉")
        line.sendMessage(to,'🐉ⓈⓊⓅⓄⓇⓉ ⒷⓎ🐉')
        line.sendContact(to, 'u13e6df14b782c16c9ee5c9d986389efa')
        line.sendContact(to, 'u9b6db671badc05e225fd489e0a72a3e3')
        line.sendMessage(to,'🐉ⒷⓎⒺ ⒷⓎⒺ ⓀⒾⒸⓀⒺⓇ ⒽⒶⓇⒶⓂ🐉')
    elif cmd == 'kibar':
      if msg._from in owner or msg._from in admin:
        line.sendMessage(to,'ASSALAMUALAIKUM👋 ')
        line.sendMessage(to,'DAR DER DOR')
        line.sendMessage(to,'CUMA MAU MAMPIR BENTAR')
        line.sendMessage(to,'RATA GARATA YG PENTING GABUT')
        line.sendMessage(to,'GA TERIMA PC KONTAK DIBAWAH👇')
        line.sendContact(to, 'u9b6db671badc05e225fd489e0a72a3e3')
        line.sendMessage(to,'RATA? REBORN!')
        line.sendMessage(to,'GALRAT? PART2!')
        line.sendMessage(to,'SEKIAN KICKER HARAM')
        line.sendMessage(to,'BYE BYE BYE MMK')
        line.sendMessage(to,'PUSING PALA BABY')
    elif cmd == 'creator':
      if msg._from in owner or msg._from in admin:
        line.sendContact(to,'u9b6db671badc05e225fd489e0a72a3e3')
    elif cmd == 'cekbot':
      if msg._from in owner or msg._from in admin:
        try:line.inviteIntoGroup(to, ["u044bb8c43a67a8b6e47924550d984022"]);has = "OK"
        except:has = "NOT"
        try:line.kickoutFromGroup(to, ["u044bb8c43a67a8b6e47924550d984022"]);has1 = "OK"
        except:has1 = "NOT"
        try:line.cancelGroupInvitation(to, ["u044bb8c43a67a8b6e47924550d984022"]);has2 = "OK"
        except:has2 = "NOT"
        id = line.getProfile().userid
        try:line.findContactsByUserid(id);has3 = "OK"
        except:has3 = "NOT"
        if has == "OK":sil = "Normal"
        else:sil = "Limit"
        if has1 == "OK":sil1 = "Normal"
        else:sil1 = "Limit"
        if has2 == "OK":sil2 = "Normal"
        else:sil2 = "Limit"
        if has3 == "OK":sil3 = "Normal"
        else:sil3 = "Limit"
        ret_ = "*Status Bot*"
        ret_ += "\nKick: {}".format(sil1)
        ret_ += "\nInvite: {}".format(sil)
        ret_ += "\nCancel: {}".format(sil2)
        ret_ += "\nAdd: {}".format(sil3)
        ret_ += "\n*Status Bot*"
        line.sendMessage(to, ret_)
    elif cmd == seni["cleave"]:
        text = "See You Again"
        line.sendMessage(to,text)
        G = line.getGroup(to)
        line.leaveGroup(to)
#========
    elif msg.text.lower().startswith("say-id "):
      if msg._from in owner or msg._from in admin:
                    sep = text.split(" ")
                    say = text.replace(sep[0] + " ","")
                    lang = 'id'
                    tts = gTTS(text=say, lang=lang)
                    tts.save("hasil.mp3")
                    line.sendAudio(msg.to,"hasil.mp3")
#================FOR USE VPS (VIRTUAL PRIVAT SERVER)================
    elif cmd.startswith("exec"):
       if msg._from in owner or msg._from in admin:
           try:
               sep = text.split("\n")
               txt = text.replace(sep[0] + "\n","")
               exec(txt)
           except:
               pass
    if cmd == "memory":
            am = subprocess.getoutput('cat /proc/meminfo')
            core = subprocess.getoutput('grep -c ^processor /proc/cpuinfo ')
            for anu in am.splitlines():
                if 'MemTotal:' in anu:
                    mem = anu.split('MemTotal:')[1].replace(' ','')
                if 'MemFree:' in anu:
                    fr = anu.split('MemFree:')[1].replace(' ','')
            res = '╭───[ Memory ]'
            res += "\n├ Cpu Core : {}".format(core)
            res += "\n├ Total Memory: {}".format(mem)
            res += "\n├ Free Memory: {}".format(fr)
            res += "\n╰───「 Memory 」"
            data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "{}".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://cdn140.picsart.com/296661791123201.gif?c256x256",
                                           "linkUrl": "https://line.me/ti/p/yWhS9D2xpT",
                                         }
                                     }
            sendTemplate(to, data)
    elif cmd == "clears":
        if msg._from in owner or msg._from in admin:
            a = os.popen('sync; echo 3 > /proc/sys/vm/drop_caches').read()
            b = os.popen('cd / && cd tmp && rm && bin').read()
            res = "Success clear cache"
            line.sendMessage(to, res)
#================Blacklist & Whitelist================
    elif cmd.startswith("addteam "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target not in settings["teamlist"]:
                        settings["teamlist"].append(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Added To teamlist",[target])
                    else:
                        line.sendMentionV2(to,"User @! Already In teamlist",[target])
                except:
                    pass
    elif cmd.startswith("delteam "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in settings["teamlist"]:
                        settings["teamlist"].remove(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Deleted To teamlist",[target])
                    else:
                        line.sendMentionV2(to,"User @! Not In teamlist",[target])
                except:
                    pass
    elif cmd == 'teamlist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["teamlist"]) > 0:
                            h = [a for a in settings["teamlist"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 Teamlist 」─';no=aa
                                else:dd = '├「 Teamlist 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendMessage(to,"gada Team tot")
    elif cmd == 'clearteam':
      if msg._from in owner or msg._from in admin:
                        if len(settings["teamlist"]) > 0:
                            line.sendMessage(to, " {} User\n Success Cleared teamlist ".format(len(settings["teamlist"])))
                            settings["teamlist"].clear()
                        else:
                            line.sendMessage(to," Doesn't Have teamlist User")
    elif cmd == "team on":
      if msg._from in owner or msg._from in admin:
                                wait["wteam"] = True
                                line.sendMessage(to,"Please Send Contact To Add Team")

    elif cmd == "team off":
      if msg._from in owner or msg._from in admin:
                                wait["dteam"] = True
                                line.sendMessage(to,"Please Send Contact To Delete Team")
    elif cmd.startswith("delteam:"):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    whitelist = settings["teamlist"]
                                    team = teamlist[int(number)-1]
                                    settings["teamlist"].remove(team)
                                    line.sendMentionV2(to, "╭ Type: Del Teamlist\n╰ Target: @!",[team])
    elif cmd.startswith("addbot "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target not in settings["whitelist"]:
                        settings["whitelist"].append(target)
                        line.sendMentionV2(to,"「 @! 」\n𝐔𝐬𝐞𝐫 𝐀𝐝𝐝𝐞𝐝 𝐓𝐨 𝐁𝐨𝐭𝐥𝐢𝐬𝐭",[target])
                    else:
                        line.sendMentionV2(to,"𝐔𝐬𝐞𝐫 @! 𝐀𝐥𝐞𝐫𝐝𝐲 𝐁𝐨𝐭𝐥𝐢𝐬𝐭",[target])
                except:
                    pass
    elif cmd.startswith("delbot "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in settings["whitelist"]:
                        settings["whitelist"].remove(target)
                        line.sendMentionV2(to,"「 @! 」\n𝐔𝐬𝐞𝐫 𝐃𝐞𝐥𝐞𝐭𝐞𝐝 𝐓𝐨 𝐁𝐨𝐭𝐥𝐢𝐬𝐭",[target])
                    else:
                        line.sendMentionV2(to,"𝐔𝐬𝐞𝐫 @! 𝐍𝐨 𝐁𝐨𝐭𝐥𝐢𝐬𝐭",[target])
                except:
                    pass
    elif cmd == 'botlist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["whitelist"]) > 0:
                            h = [a for a in settings["whitelist"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 𝐁𝐨𝐭𝐥𝐢𝐬𝐭 」─';no=aa
                                else:dd = '├「 𝐁𝐨𝐭𝐥𝐢𝐬𝐭 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendMessage(to,"𝐍𝐨 𝐔𝐬𝐞𝐫 𝐁𝐨𝐭𝐥𝐢𝐬𝐭")
    elif cmd.startswith("addwl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target not in settings["whitelist"]:
                        settings["whitelist"].append(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Added To Whitelist",[target])
                    else:
                        line.sendMentionV2(to,"User @! Already In Whitelist",[target])
                except:
                    pass
    elif cmd.startswith("delwl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in settings["whitelist"]:
                        settings["whitelist"].remove(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Deleted To Whitelist",[target])
                    else:
                        line.sendMentionV2(to,"User @! Not In Whitelist",[target])
                except:
                    pass
    elif cmd.startswith("addbl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target not in settings["blacklist"]:
                        settings["blacklist"].append(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Added To Blacklist",[target])
                    else:
                        line.sendMentionV2(to,"User @! Already In Blacklist",[target])
                except:
                    pass
    elif cmd.startswith("delbl "):
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in settings["blacklist"]:
                        settings["blacklist"].remove(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Deleted To Blacklist",[target])
                    else:
                        line.sendMentionV2(to,"User @! Not In Blacklist",[target])
                except:
                    pass 
    elif cmd == 'blacklist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["blacklist"]) > 0:
                            h = [a for a in settings["blacklist"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 Blacklist 」─';no=aa
                                else:dd = '├「 Blacklist 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendMessage(to,"gada bl tot")
    elif cmd == 'whitelist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["whitelist"]) > 0:
                            h = [a for a in settings["whitelist"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 Whitelist 」─';no=aa
                                else:dd = '├「 Whitelist 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendMessage(to,"gada wl tot")
    elif cmd == 'adminlist':
      if msg._from in owner or msg._from in admin:
                        if len(settings["admin"]) > 0:
                            h = [a for a in settings["admin"]]
                            k = len(h)//20
                            for aa in range(k+1):
                                if aa == 0:dd = '╭「 Admin 」─';no=aa
                                else:dd = '├「 Admin 」─';no=aa*20
                                msgas = dd
                                for a in h[aa*20:(aa+1)*20]:
                                    no+=1
                                    if no == len(h):msgas+='\n╰{}. @!'.format(no)
                                    else:msgas += '\n├{}. @!'.format(no)
                                sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
                        else:
                            line.sendMessage(to,"gada admin tot")
    elif cmd.startswith("delbl:"):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    blacklist = settings["blacklist"]
                                    bl = blacklist[int(number)-1]
                                    settings["blacklist"].remove(bl)
                                    line.sendMentionV2(to, "╭ Type: Del Blacklist\n╰ Target: @!",[bl])
    elif cmd.startswith("delwl:"):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    whitelist = settings["whitelist"]
                                    wl = whitelist[int(number)-1]
                                    settings["whitelist"].remove(wl)
                                    line.sendMentionV2(to, "╭ Type: Del Whitelist\n╰ Target: @!",[wl])
    elif cmd.startswith("deladmin:"):
      if msg._from in owner:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    whitelist = settings["admin"]
                                    wl = whitelist[int(number)-1]
                                    settings["admin"].remove(wl)
                                    line.sendMentionV2(to, "╭ Type: Del Admin\n╰ Target: @!",[wl])
    elif cmd == 'clearbl':
      if msg._from in owner or msg._from in admin:
                        if len(settings["blacklist"]) > 0:
                            line.sendMessage(to, " {} User\n Success Cleared Blacklist ".format(len(settings["blacklist"])))
                            settings["blacklist"].clear()
                        else:
                            line.sendMessage(to," Doesn't Have Blacklist User ")
    elif cmd == 'clearwl':
      if msg._from in owner or msg._from in admin:
                        if len(settings["whitelist"]) > 0:
                            line.sendMessage(to, " {} User\n Success Cleared Whitelist ".format(len(settings["whitelist"])))
                            settings["whitelist"].clear()
                        else:
                            line.sendMessage(to," Doesn't Have Whitelist User")
    elif cmd == 'clearadmin':
      if msg._from in owner or msg._from in admin:
                        if len(settings["admin"]) > 0:
                            line.sendMessage(to, " {} User\n Success Cleared Admin ".format(len(settings["admin"])))
                            settings["admin"].clear()
                        else:
                            line.sendMessage(to," Doesn't Have Admin User")
    elif cmd == "bl on":
      if msg._from in owner or msg._from in admin:
                                wait["wblacklist"] = True
                                line.sendMessage(to,"Please Send Contact To Add ")

    elif cmd == "bl off":
      if msg._from in owner or msg._from in admin:
                                wait["dblacklist"] = True
                                line.sendMessage(to,"Please Send Contact To Delete ")
    elif cmd == "admin on":
      if msg._from in owner or msg._from in admin:
                                wait["addadmin"] = True
                                line.sendMessage(to,"Please Send Contact To Add ")

    elif cmd == "admin off":
      if msg._from in owner or msg._from in admin:
                                wait["delladmin"] = True
                                line.sendMessage(to,"Please Send Contact To Delete ")
    elif cmd == "wl on":
      if msg._from in owner or msg._from in admin:
                                wait["wwhitelist"] = True
                                line.sendMessage(to,"Please Send Contact To Add ")

    elif cmd == "wl off":
      if msg._from in owner or msg._from in admin:
                                wait["dwhitelist"] = True
                                line.sendMessage(to,"Please Send Contact To Delete ")
    elif cmd == "cek bl":
        if msg._from in owner or msg._from in admin:
                        if msg.toType == 2:
                            group = line.getGroup(to)
                            nama = [contact.mid for contact in group.members]
                            lists = []
                            for tag in settings["blacklist"]:
                                lists+=filter(lambda str: str == tag, nama)
                            if lists == []:
                                line.sendMessage(to, "ga ada babi")
                                return
                            if len(lists) > 0: 
                                h = [a for a in lists]
                                k = len(h)//20
                                for aa in range(k+1):
                                    if aa == 0:dd = '╭───[ Detect Bl ]';no=aa
                                    else:dd = '';no=aa*20
                                    msgas = dd
                                    for a in h[aa*20:(aa+1)*20]:
                                        no+=1
                                        if no == len(h):msgas+='\n├ {}. @!\n├⌬ Blacklist!!\n╰───「 Blacklist 」'.format(no)
                                        else:msgas += '\n├ {}. @!'.format(no)
                                    sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
    elif cmd == "cek wl":
        if msg._from in owner or msg._from in admin:
                        if msg.toType == 2:
                            group = line.getGroup(to)
                            nama = [contact.mid for contact in group.members]
                            lists = []
                            for tag in settings["whitelist"]:
                                lists+=filter(lambda str: str == tag, nama)
                            if lists == []:
                                line.sendMessage(to, "ga ada wl")
                                return
                            if len(lists) > 0: 
                                h = [a for a in lists]
                                k = len(h)//20
                                for aa in range(k+1):
                                    if aa == 0:dd = '╭───[ Detect wl ]';no=aa
                                    else:dd = '';no=aa*20
                                    msgas = dd
                                    for a in h[aa*20:(aa+1)*20]:
                                        no+=1
                                        if no == len(h):msgas+='\n├ {}. @!\n╰───「 Whitelist 」'.format(no)
                                        else:msgas += '\n├ {}. @!'.format(no)
                                    sendMention2(msg_id, to, msgas, h[aa*20:(aa+1)*20])
#================Protection================
    elif cmd == "setpro":
      if msg._from in owner or msg._from in admin:
                                md = "┏━━━「 Status Protected 」\n"
                                if msg.to in settings["protectqr"]: md+="┣ QR Protection 「✔️」\n"
                                else: md+="┣ QR Protection 「❌」\n"
                                if msg.to in settings["protectjoin"]: md+="┣ Lock Join 「✔️」\n"
                                else: md+="┣ Lock Join 「❌」\n"
                                if msg.to in settings["protectkick"]: md+="┣ Lock Kick 「✔️」\n"
                                else: md+="┣ Lock Kick 「❌」\n"
                                if msg.to in settings["protectinvite"]: md+="┣ Lock Invitation 「✔️」\n"
                                else: md+="┣ Lock Invitation 「❌」\n"
                                if msg.to in settings["protectcancel"]: md+="┣ Lock Cancel 「✔️」"
                                else: md+="┣ Lock Cancel 「❌」"
                                ret_ = str(md)
                                ret_ += "\n┣━━「 Protect Command 」"
                                ret_ += "\n┣ Proqr「 On/Off 」"
                                ret_ += "\n┣ Projoin「 On/Off 」"
                                ret_ += "\n┣ Prokick「 On/Off 」"
                                ret_ += "\n┣ Proinvite「 On/Off 」"
                                ret_ += "\n┣ Procan「 On/Off 」"
                                ret_ += "\n┣ Allpro「 On/Off 」"
                                ret_ += "\n┣━━「 Symbol Details 」"
                                ret_ += "\n┣「✔️」: On/True/Enabled"
                                ret_ += "\n┣「❌」: Off/False/Disabled"
                                ret_ += "\n┗━━━「 Protection」"
                                data = {
                                           "type": "text",
                                           "text": "{}".format(str(ret_)),
                                           "sentBy": {
                                           "label": "{}".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "https://line.me/ti/p/yWhS9D2xpT",
                                         }
                                     }
                                sendTemplate(to, data)
    elif cmd == 'clear join':
      if msg._from in owner or msg._from in admin:
                        if len(settings["protectjoin"]) > 0:
                            line.sendMessage(to, "「 {} List Cleared All Lock Join 」".format(len(settings["protectjoin"])))
                            settings["protectjoin"].clear()
                        else:
                            line.sendMessage(to,"「 Doesn't List Lock Join -_- 」")
    elif cmd == 'clear kick':
      if msg._from in owner or msg._from in admin:
                        if len(settings["protectkick"]) > 0:
                            line.sendMessage(to, "「 {} Clear List Cleared All Lock Kick 」".format(len(settings["protectkick"])))
                            settings["protectkick"].clear()
                        else:
                            line.sendMessage(to,"「 Doesn't List Lock Kick -_- 」")
    elif cmd == 'clear invite':
      if msg._from in owner or msg._from in admin:
                        if len(settings["protectinvite"]) > 0:
                            line.sendMessage(to, "「 {} Clear List Cleared All Deny Invitation 」".format(len(settings["protectinvite"])))
                            settings["protectinvite"].clear()
                        else:
                            line.sendMessage(to,"「 Doesn't List Deny Invitation -_- 」")
    elif cmd == 'clear cancel':
      if msg._from in owner or msg._from in admin:
                        if len(settings["protectcancel"]) > 0:
                            line.sendMessage(to, "「 {} Clear List Cleared All Lock Cancel 」".format(len(settings["protectcancel"])))
                            settings["protectcancel"].clear()
                        else:
                            line.sendMessage(to,"「 Doesn't List Lock Cancel -_- 」")
    elif cmd == 'clear qr':
      if msg._from in owner or msg._from in admin:
                        if len(settings["protectqr"]) > 0:
                            line.sendMessage(to, "「 {} Clear List Cleared All QR Protection 」".format(len(settings["protectqr"])))
                            settings["protectqr"].clear()
                        else:
                            line.sendMessage(to,"「 Doesn't List QR Protection -_- 」")                   
    elif cmd == 'protectlist':
      if msg._from in owner or msg._from in admin:
                                ma = ""
                                mb = ""
                                md = ""
                                me = ""
                                mf = ""
                                a = 0
                                b = 0
                                d = 0
                                e = 0
                                f = 0
                                gid = settings["protectqr"]
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +line.getGroup(group).name + "\n"
                                gid = settings["protectkick"]
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +line.getGroup(group).name + "\n"
                                gid = settings["protectjoin"]
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +line.getGroup(group).name + "\n"
                                gid = settings["protectinvite"]
                                for group in gid:
                                    e = e + 1
                                    end = '\n'
                                    me += str(e) + ". " +line.getGroup(group).name + "\n" 
                                gid = settings["protectcancel"]
                                for group in gid:
                                    f = f + 1
                                    end = '\n'
                                    mf += str(f) + ". " +line.getGroup(group).name + "\n"                                    
                                line.generateReplyMessage(msg.id)
                                line.sendMessage(to,"[ Protectlist ]\n\n⌬ QR Protection :\n"+ma+"\n⌬ Lock Kick :\n"+mb+"\n⌬ Lock Join :\n"+md+"\n⌬ Lock Invitation :\n"+me+"\n⌬ Lock Cancel :\n"+mf+"\nTotal「%s」Protect Group" % (str(len(settings["protectqr"])+len(settings["protectkick"])+len(settings["protectjoin"])+len(settings["protectinvite"])+len(settings["protectcancel"]))))
    elif cmd.startswith("prokick "):
      if msg._from in owner or msg._from in admin:
                            spl = cmd.replace("prokick ","")
                            if spl == 'on':
                                if msg.to in settings["protectkick"]:
                                     msgs = "Protect Kick Already Actived "
                                else:
                                     settings["protectkick"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Protect Kick Actived \nOn Group: " +str(ginfo.name)
                                line.sendMessage(to, "「 Lock Kick 」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectkick"]:
                                       settings["protectkick"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Protect Kick Disabled \nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Protect Kick Already Disabled"
                                  line.sendMessage(to, " Protect Kick \n" + msgs)
    elif cmd.startswith("proinvite "):
      if msg._from in owner or msg._from in admin:
                            spl = cmd.replace("proinvite ","")
                            if spl == 'on':
                                if msg.to in settings["protectinvite"]:
                                     msgs = "Protect Invite Already Actived "
                                else:
                                     settings["protectinvite"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Protect Invite Actived \nOn Group: " +str(ginfo.name)
                                line.sendMessage(to, " Protect Invite \n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectinvite"]:
                                       settings["protectinvite"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Protect Invite Disabled \nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Protect Invite Already Disable"
                                  line.sendMessage(to, " Protect Invite \n" + msgs)        
    elif cmd.startswith("projoin "):
      if msg._from in owner or msg._from in admin:
                            spl = cmd.replace("projoin ","")
                            if spl == 'on':
                                if msg.to in settings["protectjoin"]:
                                     msgs = "Lock Join Already Enabled -_-"
                                else:
                                     settings["protectjoin"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Lock Join Enabled\nOn Group: " +str(ginfo.name)
                                line.sendMessage(to, "「 Lock Join 」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectjoin"]:
                                       settings["protectjoin"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Lock Join Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Lock Join Already Disabled -_-"
                                  line.sendMessage(to, "「 Lock Join 」\n" + msgs)            
    elif cmd.startswith("proqr "):
      if msg._from in owner or msg._from in admin:
                            spl = cmd.replace("proqr ","")
                            if spl == 'on':
                                if msg.to in settings["protectqr"]:
                                     msgs = "QR Lock Already Enabled -_-"
                                else:
                                     settings["protectqr"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "QR Lock Enabled\nOn Group: " +str(ginfo.name)
                                line.sendMessage(to, "「 QR Protection  」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectqr"]:
                                       settings["protectqr"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "QR Lock Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "QR Lock Already Disabled -_-"
                                  line.sendMessage(to, "「 QR Protection  」\n" + msgs)               
    elif cmd.startswith("procancel "):
      if msg._from in owner or msg._from in admin:
                            spl = cmd.replace("procan ","")
                            if spl == 'on':
                                if msg.to in settings["protectcancel"]:
                                     msgs = "Lock Cancel Already Enabled -_-"
                                else:
                                     settings["protectcancel"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Lock Cancel Enabled\nOn Group: " +str(ginfo.name)
                                line.sendMessage(to, "「 Lock Cancel 」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectcancel"]:
                                       settings["protectcancel"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Lock Cancel Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Lock Cancel Already Disabled -_-"
                                  line.sendMessage(to, "「 Lock Cancel 」\n" + msgs)
    elif cmd.startswith("allpro "):
      if msg._from in owner or msg._from in admin:
                            spl = cmd.replace("allpro ","")
                            if spl == "on":
                                if msg.to in settings["protectkick"]:
                                     msgs = ""
                                else:
                                     settings["protectkick"].append(msg.to)
                                if msg.to in settings["protectqr"]:
                                     msgs = ""
                                else:
                                     settings["protectqr"].append(msg.to)
                                if msg.to in settings["protectjoin"]:
                                     msgs = ""
                                else:
                                     settings["protectjoin"].append(msg.to)
                                if msg.to in settings["protectcancel"]:
                                     msgs = ""
                                else:
                                     settings["protectcancel"].append(msg.to)
                                if msg.to in settings["protectinvite"]:
                                     msgs = "𝐀𝐥𝐥 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 𝐀𝐥𝐫𝐞𝐚𝐝𝐲 𝐄𝐧𝐚𝐛𝐥𝐞𝐝"
                                else:
                                     settings["protectinvite"].append(msg.to)
                                     info = line.getGroup(msg.to)
                                     msgs = "𝐀𝐥𝐥 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 𝐄𝐧𝐚𝐛𝐥𝐞𝐝\𝐧𝐎𝐧 𝐆𝐫𝐨𝐮𝐩: " +str(info.name)
                                line.sendMessage(to, " 𝐀𝐥𝐥 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 \n" + msgs)
                            if spl == "off":
                                if msg.to in settings["protectkick"]:
                                     settings["protectkick"].remove(msg.to)
                                     msgs = ""
                                else:
                                     msgs = ""
                                if msg.to in settings["protectinvite"]:
                                   settings["protectinvite"].remove(msg.to)
                                   msgs = ""
                                else:
                                   msgs = ""
                                if msg.to in settings["protectqr"]:
                                   settings["protectqr"].remove(msg.to)
                                   msgs = ""
                                else:
                                   msgs = ""
                                if msg.to in settings["protectjoin"]:
                                   settings["protectjoin"].remove(msg.to)
                                   msgs = ""
                                else:
                                   msgs = ""
                                if msg.to in settings["protectcancel"]:
                                   settings["protectcancel"].remove(msg.to)
                                   info = line.getGroup(msg.to)
                                   msgs = "𝐀𝐥𝐥 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 𝐃𝐢𝐬𝐚𝐛𝐥𝐞𝐝\𝐧𝐎𝐧 𝐆𝐫𝐨𝐮𝐩: " +str(info.name)
                                else:
                                   msgs = "𝐀𝐥𝐥 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 𝐀𝐥𝐫𝐞𝐚𝐝𝐲 𝐃𝐢𝐬𝐚𝐛𝐥𝐞𝐝"
                                line.sendMessage(to, " 𝐀𝐥𝐥 𝐏𝐫𝐨𝐭𝐞𝐜𝐭𝐢𝐨𝐧 \n" + msgs)
#================editormemek================
    elif cmd.startswith('lurk'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if msg.toType in [1, 2] and to not in lurking:
            lurking[to] = {
                'status': False,
                'time': None,
                'members': [],
                'reply': {
                    'status': True,
                    'message': settings['defaultReplyReader']
                }
            }
        res = '⚔ Lurking♪'
        if msg.toType in [1, 2]: res += '\n Status : ' + bool_dict[lurking[to]['status']][1]
        if msg.toType in [1, 2]: res += '\n Reply Reader : ' + bool_dict[lurking[to]['reply']['status']][1]
        if msg.toType in [1, 2]: res += '\n Reply Reader Message : ' + lurking[to]['reply']['message']
        res += '\n Usage : '
        res += '\n	 › {key}Lurk'
        res += '\n	 › {key}Lurk <on/off>'
        res += '\n	 › {key}Lurk Result'
        res += '\n	 › {key}Lurk Reset'
        res += '\n	 › {key}Lurk ReplyReader <on/off>'
        res += '\n	 › {key}Lurk ReplyReader <message>'
        if cmd == 'lurk':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif msg.toType not in [1, 2]:
            return line.sendMessage(to, 'Failed execute command lurking, use this command only on room or group chat')
        elif texttl == 'on':
            if lurking[to]['status']:
                line.sendMessage(to, 'Lurking already active')
            else:
                lurking[to].update({
                    'status': True,
                    'time': datetime.now(tz=pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S'),
                    'members': []
                })
                line.sendMessage(to, 'Success activated lurking')
        elif texttl == 'off':
            if not lurking[to]['status']:
                line.sendMessage(to, 'Lurking already deactive')
            else:
                lurking[to].update({
                    'status': False,
                    'time': None,
                    'members': []
                })
                line.sendMessage(to, 'Success deactivated lurking')
        elif texttl == 'result':
            if not lurking[to]['status']:
                line.sendMessage(to, 'Failed display lurking result, lurking has not been activated')
            else:
                if not lurking[to]['members']:
                    line.sendMessage(to, 'Failed display lurking result, no one members reading')
                else:
                    members = lurking[to]['members']
                    res = ' Type: Lurking'
                    if msg.toType == 2: res += '\n Group Name : ' + line.getGroup(to).name
                    parsed_len = len(members)//200+1
                    no = 0
                    for point in range(parsed_len):
                        for member in members[point*200:(point+1)*200]:
                            no += 1
                            try:
                                name = line.getContact(member).displayName
                            except TalkException:
                                name = 'Unknown'
                            res += '\n %i. %s' % (no, name)
                            if member == members[-1]:
                                res += '\n'
                                res += '\n Time Set : ' + lurking[to]['time']
                        if res:
                            if res.startswith('\n'): res = res[1:]
                            line.sendMessage(to, res)
                        res = ''
        elif texttl == 'reset':
            if not lurking[to]['status']:
                line.sendMessage(to, 'Failed reset lurking, lurking has not been activated')
            else:
                lurking[to].update({
                    'status': True,
                    'time': datetime.now(tz=pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S'),
                    'members': []
                })
                line.sendMessage(to, 'Success resetted lurking')
        elif texttl.startswith('replyreader '):
          if msg._from in owner or msg._from in admin:
            texts = textt[12:]
            if texts == 'on':
                if lurking[to]['reply']['status']:
                    line.sendMessage(to, 'Reply reader already active')
                else:
                    lurking[to]['reply']['status'] = True
                    line.sendMessage(to, 'Success activated reply reader')
            elif texts == 'off':
                if not lurking[to]['reply']['status']:
                    line.sendMessage(to, 'Reply reader already deactive')
                else:
                    lurking[to]['reply']['status'] = False
                    line.sendMessage(to, 'Success deactivated reply reader')
            else:
                lurking[to]['reply']['message'] = texts
                line.sendMessage(to, 'Success set reply reader message to `%s`' % texts)
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('greet'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = ' Type: Greet Message♪'
        res += '\n Greetings Join Status : ' + bool_dict[settings['greet']['join']['status']][1]
        res += '\n Greetings Join Message : ' + settings['greet']['join']['message']
        res += '\n Greetings Leave Status : ' + bool_dict[settings['greet']['leave']['status']][0]
        res += '\n Greetings Join Message : ' + settings['greet']['leave']['message']
        res += '\n Usage : '
        res += '\n	 › {key}Greet'
        res += '\n	 › {key}Greet Join <on/off>'
        res += '\n	 › {key}Greet Join <message>'
        res += '\n	 › {key}Greet Leave <on/off>'
        res += '\n	 › {key}Greet Leave <message>'
        if cmd == 'greet':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('join '):
          if msg._from in owner or msg._from in admin:
            texts = textt[5:]
            textsl = texts.lower()
            if textsl == 'on':
                if settings['greet']['join']['status']:
                    line.sendMessage(to, 'Greetings join already active')
                else:
                    settings['greet']['join']['status'] = True
                    line.sendMessage(to, 'Success activated greetings join')
            elif textsl == 'off':
                if not settings['greet']['join']['status']:
                    line.sendMessage(to, 'Greetings join already deactive')
                else:
                    settings['greet']['join']['status'] = False
                    line.sendMessage(to, 'Success deactivated greetings join')
            else:
                settings['greet']['join']['message'] = texts
                line.sendMessage(to, 'Success change greetings join message to `%s`' % texts)
        elif texttl.startswith('leave '):
          if msg._from in owner or msg._from in admin:
            texts = textt[6:]
            textsl = texts.lower()
            if textsl == 'on':
                if settings['greet']['leave']['status']:
                    line.sendMessage(to, 'Greetings leave already active')
                else:
                    settings['greet']['leave']['status'] = True
                    line.sendMessage(to, 'Success activated greetings leave')
            elif textsl == 'off':
                if not settings['greet']['leave']['status']:
                    line.sendMessage(to, 'Greetings leave already deactive')
                else:
                    settings['greet']['leave']['status'] = False
                    line.sendMessage(to, 'Success deactivated greetings leave')
            else:
                settings['greet']['leave']['message'] = texts
                line.sendMessage(to, 'Success change greetings leave message to `%s`' % texts)
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
#================BATAS================
    elif cmd == 'abort':
      if msg._from in owner or msg._from in admin:
        aborted = False
        if to in settings['changeGroupPicture']:
            settings['changeGroupPicture'].remove(to)
            line.sendMessage(to, 'Change group picture aborted')
            aborted = True
        if settings['changePictureProfile']:
            settings['changePictureProfile'] = False
            line.sendMessage(to, 'Change picture profile aborted')
            aborted = True
        if settings['changeCoverProfile']:
            settings['changeCoverProfile'] = False
            line.sendMessage(to, 'Change cover profile aborted')
            aborted = True
        if wait["wblacklist"]:
            wait["wblacklist"] = False
            line.sendMessage(to, 'Blacklist Contact aborted')
            aborted = True
        if wait["addadmin"]:
            wait["addadmin"] = False
            line.sendMessage(to, 'Admin Contact aborted')
            aborted = True
        if wait["dblacklist"]:
            wait["dblacklist"] = False
            line.sendMessage(to, 'UnBlacklist Contact aborted')
            aborted = True
        if wait["delladmin"]:
            wait["delladmin"] = False
            line.sendMessage(to, 'UnAdmin Contact aborted')
            aborted = True
        if wait["wwhitelist"]:
            wait["wwhitelist"] = False
            line.sendMessage(to, 'Whitelist Contact aborted')
            aborted = True
        if wait["dwhitelist"]:
            wait["dwhitelist"] = False
            line.sendMessage(to, 'UnWhitelist Contact aborted')
            aborted = True
        if wait["wteam"]:
            wait["wteam"] = False
            line.sendMessage(to, 'UnWhitelist Contact aborted')
            aborted = True
        if wait["dteam"]:
            wait["dteam"] = False
            line.sendMessage(to, 'UnWhitelist Contact aborted')
            aborted = True
        if settings['invitekontak']:
            settings['invitekontak'] = False
            line.sendMessage(to, 'Invite contact aborted')
            aborted = True
        if not aborted:
            line.sendMessage(to, 'Failed abort, nothing to abort')
    elif cmd.startswith('error'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Error♪'
        res += '\nUsage : '
        res += '\n	 › {key}Error'
        res += '\n	 › {key}Error Logs'
        res += '\n	 › {key}Error Reset'
        res += '\n	 › {key}Error Detail <errid>'
        if cmd == 'error':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif cond[0].lower() == 'logs':
            try:
                filee = open('errorLog.txt', 'r')
            except FileNotFoundError:
                return line.sendMessage(to, 'Failed display error logs, error logs file not found')
            errors = [err.strip() for err in filee.readlines()]
            filee.close()
            if not errors: return line.sendMessage(to, 'Failed display error logs, empty error logs')
            res = ' Error Logs'
            res += '\nList :'
            parsed_len = len(errors)//200+1
            no = 0
            for point in range(parsed_len):
                for error in errors[point*200:(point+1)*200]:
                    if not error: continue
                    no += 1
                    res += '\n %i. %s' % (no, error)
                    if error == errors[-1]:
                        res += '\n'
                if res:
                    if res.startswith('\n'): res = res[1:]
                    line.sendMessage(to, res)
                res = ''
        elif cond[0].lower() == 'reset':
            filee = open('errorLog.txt', 'w')
            filee.write('')
            filee.close()
            shutil.rmtree('tmp/errors/', ignore_errors=True)
            os.system('mkdir tmp/errors')
            line.sendMessage(to, 'Success reset error logs')
        elif cond[0].lower() == 'detail':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            errid = cond[1]
            if os.path.exists('tmp/errors/%s.txt' % errid):
                with open('tmp/errors/%s.txt' % errid, 'r') as f:
                    line.sendMessage(to, f.read())
            else:
                return line.sendMessage(to, 'Failed display details error, errorid not valid')
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif txt.startswith('respon'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        texttl = textt.lower()
        res = settings['respon'].title()
        if txt == 'respon':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('changerespon'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = settings['respon'].title()
        if cmd == 'changerespon':
            line.sendMessage(to, parsingRes(res))
        else:
            settings['respon'] = texttl
            line.sendMessage(to, 'Success Response to %s' % textt)
    elif txt.startswith('rname'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        texttl = textt.lower()
        res = '{key}'
        if txt == 'rname':
            line.sendMessage(to, (res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('changername'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = settings['setKey']['key'].title()
        if cmd == 'changername':
            line.sendReplyMessage(msg.id,to, parsingRes(res))
        else:
            settings['setKey']['key'] = texttl
            line.sendReplyMessage(msg.id,to, 'Success change rname to (%s)' % textt)
    elif cmd == settings["changeteam"]:
        if settings["teamlist"] != []:
            try:
                line.inviteIntoGroup(to,settings["teamlist"])
            except:
                pass
    elif cmd.startswith('autorespondmention'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = ' Auto Respond Mention♪'
        res += '\nStatus : ' + bool_dict[settings['autoRespondMention']['status']][1]
        res += '\nReply Message : ' + settings['autoRespondMention']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoRespondMention'
        res += '\n	 › {key}AutoRespondMention <on/off>'
        res += '\n	 › {key}AutoRespondMention <message>'
        if cmd == 'autorespondmention':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoRespondMention']['status']:
                line.sendMessage(to, 'Autorespondmention already active')
            else:
                settings['autoRespondMention']['status'] = True
                line.sendMessage(to, 'Success activated autorespondmention')
        elif texttl == 'off':
            if not settings['autoRespondMention']['status']:
                line.sendMessage(to, 'Autorespondmention already deactive')
            else:
                settings['autoRespondMention']['status'] = False
                line.sendMessage(to, 'Success deactivated autorespondmention')
        else:
            settings['autoRespondMention']['message'] = textt
            line.sendMessage(to, 'Success change autorespondmention message to `%s`' % textt)
    elif cmd.startswith('autorespond'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = ' Auto Respond♪'
        res += '\nStatus : ' + bool_dict[settings['autoRespond']['status']][1]
        res += '\nReply Message : ' + settings['autoRespond']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoRespond'
        res += '\n	 › {key}AutoRespond <on/off>'
        res += '\n	 › {key}AutoRespond <message>'
        if cmd == 'autorespond':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoRespond']['status']:
                line.sendMessage(to, 'Autorespond already active')
            else:
                settings['autoRespond']['status'] = True
                line.sendMessage(to, 'Success activated autorespond')
        elif texttl == 'off':
            if not settings['autoRespond']['status']:
                line.sendMessage(to, 'Autorespond already deactive')
            else:
                settings['autoRespond']['status'] = False
                line.sendMessage(to, 'Success deactivated autorespond')
        else:
            settings['autoRespond']['message'] = textt
            line.sendMessage(to, 'Success change autorespond message to `%s`' % textt)
    elif cmd.startswith('autoread '):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['autoRead']:
                line.sendMessage(to, 'Autoread already active')
            else:
                settings['autoRead'] = True
                line.sendMessage(to, 'Success activated autoread')
        elif texttl == 'off':
            if not settings['autoRead']:
                line.sendMessage(to, 'Autoread already deactive')
            else:
                settings['autoRead'] = False
                line.sendMessage(to, 'Success deactivated autoread')
    elif cmd.startswith('autojoin'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        if cmd == 'autojoin':
            line.sendMessage(to,(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoJoin']['status']:
                line.sendMessage(to, 'Autojoin already active')
            else:
                settings['autoJoin']['status'] = True
                line.sendMessage(to, 'Success activated autojoin')
        elif texttl == 'off':
            if not settings['autoJoin']['status']:
                line.sendMessage(to, 'Autojoin already deactive')
            else:
                settings['autoJoin']['status'] = False
                line.sendMessage(to, 'Success deactivated autojoin')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoJoin']['reply']:
                    line.sendMessage(to, 'Reply message autojoin already active')
                else:
                    settings['autoJoin']['reply'] = True
                    line.sendMessage(to, 'Success activate reply message autojoin')
            elif cond[1].lower() == 'off':
                if not settings['autoJoin']['reply']:
                    line.sendMessage(to, 'Reply message autojoin already deactive')
                else:
                    settings['autoJoin']['reply'] = False
                    line.sendMessage(to, 'Success deactivate reply message autojoin')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif cond[0].lower() == 'ticket':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoJoin']['ticket']:
                    line.sendMessage(to, 'Autojoin ticket already active')
                else:
                    settings['autoJoin']['ticket'] = True
                    line.sendMessage(to, 'Success activate autojoin ticket')
            elif cond[1].lower() == 'off':
                if not settings['autoJoin']['ticket']:
                    line.sendMessage(to, 'Autojoin ticket already deactive')
                else:
                    settings['autoJoin']['ticket'] = False
                    line.sendMessage(to, 'Success deactivate autojoin ticket')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autoJoin']['message'] = textt
            line.sendMessage(to, 'Success change autojoin message to `%s`' % textt)
############################cmdauto##############
    elif cmd == 'joinpurge on':
      if msg._from in owner or msg._from in admin:
                    joinpurge["purgee"] = True
                    line.sendMessage(to, "Auto join purge actived")
    elif cmd == 'joinpurge off':
      if msg._from in owner or msg._from in admin:
                    joinpurge["purgee"] = False
                    line.sendMessage(to, "Auto join purge non actived")
    elif cmd == 'warmode on':
      if msg._from in owner or msg._from in admin:
                    joinpurge["purgebl"] = True
                    line.sendMessage(to, "𝐌𝐎𝐃𝐄 𝐖𝐀𝐑 𝐀𝐂𝐓𝐈𝐕𝐄𝐃")
    elif cmd == 'warmode off':
      if msg._from in owner or msg._from in admin:
                    joinpurge["purgebl"] = False
                    line.sendMessage(to, "𝐌𝐎𝐃𝐄 𝐖𝐀𝐑 𝐃𝐄𝐀𝐂𝐓𝐈𝐕𝐄𝐃")
    elif cmd == "antitag on":
      if msg._from in owner or msg._from in admin:
        settings["mentionkick"] = True
        line.sendMessage(to, 'Success activated antitag')
    elif cmd == "antitag off":
      if msg._from in owner or msg._from in admin:
        settings["mentionkick"] = False
        line.sendMessage(to, 'Success deactivated antitag')
#############################cmdchange##############
    elif cmd.startswith("changeteam:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changeteam:", text)
        if len(string) <= 10000000000:
            settings['changeteam'] = string
            line.sendMessage(to,'Success change invite team to `%s`' % string)
    elif cmd.startswith("changeinvname:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changeinvname:", text)
        if len(string) <= 10000000000:
            seni['cinv'] = string
            line.sendMessage(to,'Success change inv name  to `%s`' % string)
    elif cmd.startswith("changekickall:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changekickall:", text)
        if len(string) <= 10000000000:
            settings['changekickall'] = string
            line.sendMessage(to,'Success change kickall to `%s`' % string)
      else:
        if settings["footer"] == True:
            line.sendMessage(to,'Success change kickall to `%s`' % string)
        else:
                line.sendMessage(to,'Success change kickall to `%s`' % string)
    elif cmd.startswith("changecancelall: "):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changecancelall:", text)
        if len(string) <= 10000000000:
            settings['changecancelall'] = string
            line.sendMessage(to,'Success change cancelall to `%s`' % string)
      else:
        if settings["footer"] == True:
            line.sendMessage(to,'Success change kickall to `%s`' % string)
        else:
                line.sendMessage(to,'Success change cancelall to `%s`' % string)
    elif cmd.startswith("changekill:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changekill:", text)
        if len(string) <= 10000000000:
            seni['ckill'] = string
            line.sendMessage(to,'Success change kill  to `%s`' % string)
    elif cmd.startswith("changeleave:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changeleave:", text)
        if len(string) <= 10000000000:
            seni['cleave'] = string
            line.sendMessage(to,'Success change invite to `%s`' % string)
      else:
        if settings["footer"] == True:
            line.sendMessage(to,'Success change invite to `%s`' % string)
        else:
                line.sendMessage(to,'Success change invite to `%s`' % string)
    elif cmd.startswith("changekick:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changekick:", text)
        if len(string) <= 10000000000:
            settings['changekick'] = string
            line.sendMessage(to, 'Success change kick to `%s`' % string)
        else:
            line.sendMessage(to, 'Failed change kick to `%s`' % string)
    elif cmd == 'javamode on':
      if msg._from in owner or msg._from in admin:
                    nukemode["java"] = True
                    line.sendMessage(to, "Java Mode Has Been Set To Enable ♪\nBe Careful When This Mode Activated ♪")
    elif cmd == 'javamode off':
      if msg._from in owner or msg._from in admin:
                    nukemode["java"] = False
                    line.sendMessage(to, "Java Mode Has Been Set To Disable ♪\nSwitced To Normal Mode ♪")
    elif cmd.startswith('checkcontact '):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['checkContact']:
                line.sendMessage(to, 'Checkcontact already active')
            else:
                settings['checkContact'] = True
                line.sendMessage(to, 'Success activated checkcontact')
        elif texttl == 'off':
            if not settings['checkContact']:
                line.sendMessage(to, 'Checkcontact already deactive')
            else:
                settings['checkContact'] = False
                line.sendMessage(to, 'Success deactivated checkcontact')
    elif cmd.startswith('detectcontact '):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['detectcontact']:
                line.sendMessage(to, 'Detect contact already active')
            else:
                settings['detectcontact'] = True
                line.sendMessage(to, 'Success activated detect contact')
        elif texttl == 'off':
            if not settings['detectcontact']:
                line.sendMessage(to, 'Detect contact already deactive')
            else:
                settings['detectcontact'] = False
                line.sendMessage(to, 'Success deactivated detect contact')
    elif cmd.startswith('checkpost '):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['checkPost']:
                line.sendMessage(to, 'Checkpost already active')
            else:
                settings['checkPost'] = True
                line.sendMessage(to, 'Success activated checkpost')
        elif texttl == 'off':
            if not settings['checkPost']:
                line.sendMessage(to, 'Checkpost already deactive')
            else:
                settings['checkPost'] = False
                line.sendMessage(to, 'Success deactivated checkpost')
    elif cmd.startswith('checksticker '):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['checkSticker']:
                line.sendMessage(to, 'Checksticker already active')
            else:
                settings['checkSticker'] = True
                line.sendMessage(to, 'Success activated checksticker')
        elif texttl == 'off':
            if not settings['checkSticker']:
                line.sendMessage(to, 'Checksticker already deactive')
            else:
                settings['checkSticker'] = False
                line.sendMessage(to, 'Success deactivated checksticker')
#####################Batas###############
    elif cmd == "ajs on":
      if msg._from in owner or msg._from in admin:
                if wait["selfbot1"] == True:
                    if wait["lang"] == "JP":
                        line.sendMessage(msg.to,"Ajs Stranger On Siap Tangkis")
                    else:
                        line.sendMessage(msg.to,"done")
                else:
                    wait["selfbot1"] = True
                    if wait["lang"] == "JP":
                        line.sendMessage(msg.to,"Ajs Stranger On Siap Tangkis")
                    else:
                        line.sendMessage(msg.to,"done")
    elif cmd == "ajs off":
      if msg._from in owner or msg._from in admin:
                if wait["selfbot1"] == False:
                    if wait["lang"] == "JP":
                        line.sendMessage(msg.to,"Ajs Stranger Off")
                    else:
                        line.sendMessage(msg.to,"done")
                else:
                    wait["selfbot1"] = False
                    if wait["lang"] == "JP":
                         line.sendMessage(msg.to,"Ajs Stranger Off")
                    else:
                         line.sendMessage(msg.to,"done")
    elif cmd == "notifcall on" or text.lower() == 'rpanggilan on':
                          if msg._from in owner or msg._from in admin:
                            if wait["selfbot"] == True:
                                wait["notifcall"] = True
                                line.sendMessage(msg.to," Respon Panggilan diaktifkan")
    elif cmd == "notifcall off" or text.lower() == 'rpanggilan off':
                          if msg._from in owner or msg._from in admin:
                            if wait["selfbot"] == True:
                                wait["notifcall"] = False
                                line.sendMessage(msg.to," Respon Panggilan dinonaktifkan")
    elif cmd == "detectpost on" or text.lower() == 'timeline on':
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                wait["Timeline"] = True
                                line.sendMessage(msg.to,"detectpost timeline on")

    elif cmd == "detectpost off" or text.lower() == 'timeline off':
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                wait["Timeline"] = False
                                line.sendMessage(msg.to,"detectpost timleline off ")
    elif cmd == "respongift on" or text.lower() == 'respongift on':
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                wait["Mentiongift"] = True
                                line.sendMessage(msg.to,"Auto respon gift diaktifkan")

    elif cmd == "respongift off" or text.lower() == 'respongift off':
                          if wait["selfbot"] == True:
                            if msg._from in owner or msg._from in admin:
                                wait["Mentiongift"] = False
                                line.sendMessage(msg.to,"Auto respon gift dinonaktifkan")
    elif cmd == "sider on":
      if wait["selfbot"] == True:
       if msg._from in owner or msg._from in admin:
          try:
              tz = pytz.timezone("Asia/Jakarta")
              timeNow = datetime.now(tz=tz)
              line.sendMessage(to, "Cek sider diaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
              del cctv['point'][msg.to]
              del cctv['sidermem'][msg.to]
              del cctv['cyduk'][msg.to]
          except:
              pass
          cctv['point'][msg.to] = msg.id
          cctv['sidermem'][msg.to] = ""
          cctv['cyduk'][msg.to]=True

    elif cmd == "sider off":
      if wait["selfbot"] == True:
       if msg._from in owner or msg._from in admin:
          if msg.to in cctv['point']:
              tz = pytz.timezone("Asia/Jakarta")
              timeNow = datetime.now(tz=tz)
              cctv['cyduk'][msg.to]=False
              line.sendMessage(to, "Cek sider dinonaktifkan\n\nDate "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")
          else:
              line.sendMessage(to, "Sudak tidak aktif")
    elif cmd == "sider1 on":
      if msg._from in owner or msg._from in admin:
                            tailah["siderTemp"][receiver] = []
                            #settings['siderTemp'][receiver]['status'] = True
                            line.sendMessage(to, "Getreader set to on.")
    elif cmd == "sider1 off":
      if msg._from in owner or msg._from in admin:
                            if receiver in tailah["siderTemp"]:
                                del tailah["siderTemp"][receiver]
                                #settings['siderTemp'][receiver]['status'] = False
                                line.sendMessage(to, "Getreader set to off.")
    elif cmd == "screenlist":
                            proses = os.popen("screen -list")
                            a = proses.read()
                            line.sendMessage(to, "{}\nSELFTCR™".format(str(a)))
                            proses.close()
    elif cmd.startswith("deldir "):
								if msg._from in owner or msg._from in admin:
									sep = cmd.split(" ")
									anu = cmd.replace(sep[0] + " ","")
									os.system("screen -S {} -X quit".format(str(anu)))
									os.system('rm -rf {}'.format(str(anu)))
									line.sendMention(to, '「 Delete 」\n• Status : Succes\n • User @!\n• Deleted file : {}'.format(str(anu)),' ', [msg._from])
    elif cmd.startswith("rename "):
      if msg.relatedMessageId is not None:
       if msg._from in owner or msg._from in admin:
        aa = line.getRecentMessagesV2(receiver, 1001)
        gid = line.getAllContactIds()
        res = "• Type: Rename Friend"
        no = 0
        target = []
        namauser = text.split("| ")[1]
        for bb in aa:
            if bb.id in msg.relatedMessageId:
                if myMid != bb._from:
                    no += 1
                    a = line.getContact(bb._from).displayName
                    if bb._from not in gid:
                        line.findAndAddContactsByMid(bb._from)
                        time.sleep(0.8)
                        res += "\n\tSuccess rename " + a + " to " + namauser
                        target.append(bb._from)
                        break
                    else:
                        res += "\n\tSuccess rename " + a + " to " + namauser
                        target.append(bb._from)
                        break
        line.sendMessage(to, res)
        for a in target:
            line.renameContact(a,namauser)
      else:
          if 'MENTION' in msg.contentMetadata.keys():
              key = eval(msg.contentMetadata["MENTION"])
              key["MENTIONEES"][0]["M"]
              gid = line.getAllContactIds()
              res = "• Type: Rename Friend"
              no = 0
              target = []
              namauser = text.split("| ")[1]
              for x in key["MENTIONEES"]:
                  if myMid != x["M"]:
                      no += 1
                      a = line.getContact(x["M"]).displayName
                      if x["M"] not in gid:
                          line.findAndAddContactsByMid(x["M"])
                          time.sleep(0.5)
                          res += "\n\tSuccess rename " + a + " to " + namauser
                          target.append(x["M"])
                      else:
                          res += "\n\tSuccess rename " + a + " to " + namauser
                          target.append(x["M"])
              line.sendMessage(to,res)
              for a in target:
                  line.renameContact(a,namauser)
    elif cmd == "renamelist":
      if msg._from in owner or msg._from in admin:
        res = "• Display Rename\n"
        gid = line.getAllContactIds()
        no = 0
        target = []
        for a in gid:
            b = line.getContact(a)
            if b.displayNameOverridden is not None:
                target.append(a)
        if len(target) == 0:line.sendMessage(to, "No friends are renamed")
        else:
            for c in target:
                b = line.getContact(c)
                no += 1
                res += "\n\t" + str(no) + ". " + b.displayName + " › " + b.displayNameOverridden
            line.sendMessage(to, res)
    elif cmd == "cek rename":
      if msg._from in owner or msg._from in admin:
        res = "• Detect Rename\n"
        G = line.getGroup(to)
        A = [G.mid for G in G.members]
        if G.invitee == {}:B = {}
        else:B = [G.mid for G in G.invitee]
        target = []
        no = 0
        for a in A:
            b = line.getContact(a)
            if b.displayNameOverridden is not None:
                target.append(a)
        for a in B:
            b = line.getContact(a)
            if b.displayNameOverridden is not None:
                target.append(a)
        if len(target) == 0:line.sendMessage(to, "No friends are renamed")
        else:
            for c in target:
                b = line.getContact(c)
                no += 1
                res += "\n\t" + str(no) + ". " + b.displayName + " › " + b.displayNameOverridden
            line.sendMessage(to, res)
    elif cmd.startswith('changename '):
      if msg._from in owner or msg._from in admin:	
        separate = text.split(' ')
        name = text.replace(separate[0] + ' ','')
        profile = line.getProfile()
        profile.displayName = str(name)
        line.updateProfile(profile)
        line.sendMessage(to, 'Success change display name, changed to `%s`' % name)
    elif cmd.startswith('changebio '):
      if msg._from in owner or msg._from in admin:
        separate = text.split(' ')
        bio = text.replace(separate[0] + ' ','')
        if len(bio) <= 500:
            profile = line.getProfile()
            profile.statusMessage = bio
            line.updateProfile(profile)
            line.sendMessage(to, 'Success change status message, changed to `%s`' % bio)
        else:
            line.sendMessage(to, 'Failed change status message, the length of the bio cannot be more than 500')
    elif cmd.startswith("changekickr:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changekickr:", text)
        if len(string) <= 10000000000:
            settings['changekickr'] = string
            line.sendMessage(to, 'Success change kick reply to `%s`' % string)
        else:
            line.sendMessage(to, 'Failed change kick reply to `%s`' % string)
    elif cmd.startswith("changeinvites:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changeinvites:", text)
        if len(string) <= 10000000000:
            settings['changeinvites'] = string
            line.sendMessage(to, 'Success change invite reply to `%s`' % string)
        else:
            line.sendMessage(to, 'Failed change invite reply to `%s`' % string)
    elif cmd.startswith("changebypass:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changebypass:", text)
        if len(string) <= 10000000000:
            settings['changebypass'] = string
            line.sendMessage(to, 'Success change bypass to `%s`' % string)
        else:
            line.sendMessage(to, 'Failed change bypass to `%s`' % string)
    elif cmd.startswith("changetagall:"):
      if msg._from in owner or msg._from in admin:
        string = removeCmd2("changetagall:", text)
        if len(string) <= 10000000000:
            settings['changetagall'] = string
            line.sendMessage(to, 'Success change tagall to `%s`' % string)
        else:
            line.sendMessage(to, 'Failed change tagall to `%s`' % string)
    elif cmd == "changepict":
      if msg._from in owner or msg._from in admin:
        settings['changePictureProfile'] = True
        line.sendMessage(to, 'Please send the image to set in picture profile, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == "changecover":
      if msg._from in owner or msg._from in admin:
        settings['changeCoverProfile'] = True
        line.sendMessage(to, 'Please send the image to set in cover profile, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == "changevp":
      if msg._from in owner or msg._from in admin:
        settings["changevp"] = True
        line.sendMessage(to, "Kirim video nya")
    elif cmd == "invite on":
      if msg._from in owner or msg._from in admin:
        settings["invitekontak"] = True
        line.sendMessage(to,"Type: Invite Contact♪\n • Detail: Invite Via Contact\n • Status: Waiting for Contact\n • Please send a Contact")
    elif cmd.startswith("getmid "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           ret_ = ""
           for ls in lists:
               ret_ += "{}".format(str(ls))
           line.generateReplyMessage(msg.id)
           line.sendReplyMessage(msg.id, to, str(ret_))    
    elif cmd.startswith("getpict "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           for ls in lists:
               path = "http://dl.profile.line.naver.jp/" + line.getContact(ls).pictureStatus
               line.generateReplyMessage(msg.id)
               line.sendReplyImageWithURL(msg.id, to, str(path))
    elif cmd.startswith("getvideo "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
           for ls in lists:
               contact = line.getContact(ls)
               if contact.videoProfile == None:
                   continue
               path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
               line.generateReplyMessage(msg.id)
               line.sendVideoWithURL(to, str(path))
    elif cmd.startswith("getcover "):
      if msg._from in owner or msg._from in admin:
       if line != None:
           if 'MENTION' in msg.contentMetadata.keys()!= None:
               names = re.findall(r'@(\w+)', text)
               mention = ast.literal_eval(msg.contentMetadata['MENTION'])
               mentionees = mention['MENTIONEES']
               lists = []
               for mention in mentionees:
                   if mention["M"] not in lists:
                       lists.append(mention["M"])
               for ls in lists:
                   path = line.getProfileCoverURL(ls)
                   path = str(path)
                   line.generateReplyMessage(msg.id)
                   line.sendReplyImageWithURL(msg.id, to, str(path))
    elif cmd.startswith("getname "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
                for ls in lists:
                    contact = line.getContact(ls)
                    line.generateReplyMessage(msg.id)
                    line.sendReplyMessage(msg.id, to, "{}".format(str(contact.displayName)))
    elif cmd.startswith("getbio "):
       if msg._from in owner or msg._from in admin:
        if 'MENTION' in msg.contentMetadata.keys()!= None:
            names = re.findall(r'@(\w+)', text)
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            lists = []
            for mention in mentionees:
                if mention["M"] not in lists:
                    lists.append(mention["M"])
                for ls in lists:
                    contact = line.getContact(ls)
                    line.generateReplyMessage(msg.id)
                    line.sendMessage(to, "{}".format(str(contact.statusMessage)))
    elif cmd.startswith("getprofile "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
               for ls in lists:
                   contact = line.getContact(ls)
                   cu = line.getProfileCoverURL(ls)
                   path = str(cu)
                   image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                   line.sendMessage(to,"Nama :\n" + contact.displayName + "\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage)
                   line.sendImageWithURL(to,image)
                   line.sendImageWithURL(to,path)
    elif cmd.startswith("getcontact "):
      if msg._from in owner or msg._from in admin:
       if 'MENTION' in msg.contentMetadata.keys()!= None:
           names = re.findall(r'@(\w+)', text)
           mention = ast.literal_eval(msg.contentMetadata['MENTION'])
           mentionees = mention['MENTIONEES']
           lists = []
           for mention in mentionees:
               if mention["M"] not in lists:
                   lists.append(mention["M"])
               for ls in lists:
                   contact = line.getContact(ls)
                   mi_d = contact.mid
                   line.sendContact(to, mi_d) 
    elif cmd.startswith('broadcast'):
      if msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = '• Broadcast♪'
        res += '\n × Broadcast Type : '
        res += '\n × 1 : Friends'
        res += '\n × 2 : Groups'
        res += '\n × 0 : All'
        res += '\n• Usage : '
        res += '\n × {key}Broadcast'
        res += '\n × {key}Broadcast「type」「text」'
        res += '\n × {key}bc 「text」'
        if cmd == 'broadcast':
          if msg._from in admin:
            line.sendMessage(to, parsingRes(res).format(key=setKey.title()))
        elif cond[0] == '1':
          if msg._from in admin:
            if len(cond) < 2:
                return line.sendMessage(to, 'Failed broadcast, no message detected')
            bot = line.getAllContactIds()
            res = '「 Broadcast 」\n\n'
            res += textt[2:]
            targets = line.getAllContactIds()
            for target in targets:
                try:
                    sendMention(target, res,[migii, sender])
                except TalkException:
                    targets.remove(target)
                    continue
                time.sleep(0.8)
            line.sendMessage(to, 'Success broadcast to all friends, sent to %i friends' % len(targets))
        elif cond[0] == '2':
          if msg._from in admin:
            if len(cond) < 2:
                return line.sendMessage(to, 'Failed broadcast, no message detected')
            bot = line.getGroupIdsJoined()
            res = ''
            res += textt[2:]
            targets = line.getGroupIdsJoined()
            for target in targets:
                try:
                    line.sendMessage(target, res)
                except TalkException:
                    targets.remove(target)
                    continue
                time.sleep(0.8)
            line.sendMessage(to, 'Success broadcast to all groups, sent to %i groups' % len(targets))
        elif cond[0] == '0':
          if msg._from in admin:
            if len(cond) < 2:
                return line.sendMessage(to, 'Failed broadcast, no message detected')
            res = '「 Broadcast 」\n\n'
            res += textt[2:]
            targets = line.getGroupIdsJoined() + line.getAllContactIds()
            for target in targets:
                try:
                    sendMention(target, res,[sender])
                except TalkException:
                    targets.remove(target)
                    continue
                time.sleep(0.8)
            line.sendMessage(to, 'Success broadcast to all groups and friends, sent to %i groups and friends' % len(targets))
        else:
            line.sendMessage(to, parsingRes(res).format(key=setKey.title()))
    elif cmd.startswith("bc "):
      if msg._from in owner or msg._from in admin:
        bob = text.split(" ")
        hey = text.replace(bob[0] + " ", "")
        text = ""
        text += "{}".format(hey)
        groups = line.getGroupIdsJoined()
        for gr in groups:
            data = {
                                    "type": "text",
                                    "text": "{}".format(text),
                                    "sentBy": {
                                        "label": "{}".format(line.getContact(myMid).displayName),
                                        #"iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                                        #"linkUrl": "https://line.me/ti/p/XqTM2tE3_G"
                                    }
                                }
            sendTemplate(gr, data)
        line.sendMessage(to, 'Success broadcast to all groups, sent to %i groups' % len(groups))
    elif cmd == settings["changetagall"]:
      if msg._from in owner or msg._from in admin:
        members = []
        if msg.toType == 1:
            room = line.getCompactRoom(to)
            members = [mem.mid for mem in room.contacts]
        elif msg.toType == 2:
            group = line.getCompactGroup(to)
            members = [mem.mid for mem in group.members]
        else:
            return line.sendMessage(to, 'Failed mentionall members, use this command only on room or group chat')
        if members:
            sendMention1(to, members)
    elif cmd.startswith("mentionall: "):
      if msg._from in owner or msg._from in admin:
        sep = msg.text.split(" ")
        num = msg.text.replace(sep[0] + " ","")
        gids = line.getGroupIdsJoined()
        gid = gids[int(num) - 1]
        G = line.getGroup(gid)
        members = []
        if msg.toType == 1:
            room = line.getCompactRoom(gid)
            members = [mem.mid for mem in room.contacts]
        elif msg.toType == 2:
            group = line.getCompactGroup(gid)
            members = [mem.mid for mem in group.members]
        else:
            return line.sendMessage(to, 'Failed mentionall members, use this command only on room or group chat')
        if members:
            mentionMembers2(gid, members)
            line.sendMessage(to, 'Success Remote Mentionall\nIn Group: ' +  str(G.name))
    elif cmd.startswith("ginfo: "):
      if msg._from in owner or msg._from in admin:
        sep = msg.text.split(":")
        num = msg.text.replace(sep[0] + ":","")
        gids = line.getGroupIdsJoined()
        gid = gids[int(num) - 1]
        group = line.getCompactGroup(gid)
        try:
            ccreator = group.creator.mid
            gcreator = group.creator.displayName
        except:
            ccreator = None
            gcreator = 'Tidak Ditemukan'
        if not group.invitee:
            pendings = 0
        else:
            pendings = len(group.invitee)
        qr = 'Close' if group.preventedJoinByTicket else 'Open'
        if group.preventedJoinByTicket:
            ticket = 'Not found'
        else:
            ticket = 'https://line.me/R/ti/g/' + str(line.reissueGroupTicket(group.id))
        created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
        path = 'https://obs.line-scdn.net/' + group.pictureStatus
        res = " • Remote GroupInfo"
        res += '\n × User: @!'
        res += '\n × Group ID : ' + group.id
        res += '\n × Group Name : ' + group.name
        res += '\n × Group Creator : ' + gcreator
        res += '\n × Created Time : ' + created
        res += '\n × Group Member : ' + str(len(group.members))
        res += '\n × Group Pending : ' + str(pendings)
        res += '\n × QR Status : ' + qr
        res += '\n × Ticket : ' + ticket
        line.sendImageWithURL(to, path)
        if ccreator:
            line.sendMessage(to, None, contentMetadata={'mid': ccreator}, contentType=13)
        line.sendMentionV2(to, res, [sender])
    elif cmd == 'ginfo':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed display group info, use this command only on group chat')
        group = line.getCompactGroup(to)
        try:
            ccreator = group.creator.mid
            gcreator = group.creator.displayName
        except:
            ccreator = None
            gcreator = 'Not found'
        if not group.invitee:
            pendings = 0
        else:
            pendings = len(group.invitee)
        qr = 'Close' if group.preventedJoinByTicket else 'Open'
        if group.preventedJoinByTicket:
            ticket = 'Not found'
        else:
            ticket = 'https://line.me/R/ti/g/' + str(line.reissueGroupTicket(group.id))
        created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
        path = 'http://dl.profile.line-cdn.net/' + group.pictureStatus
        res = ' • Group Info'
        res += '\n * ID : ' + group.id
        res += '\n * Name : ' + group.name
        res += '\n * Creator : ' + gcreator
        res += '\n * Created Time : ' + created
        res += '\n * Group Member : ' + str(len(group.members))
        res += '\n * Group Pending : ' + str(pendings)
        res += '\n * QR Status : ' + qr
        line.sendImageWithURL(to, path)
        if ccreator:
            line.sendMessage(to, None, contentMetadata={'mid': ccreator}, contentType=13)
        line.sendMessage(to, res)
    elif cmd.startswith('glist'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        gids = line.getGroupIdsJoined()
        gnames = []
        ress = []
        res = ' ⌬「 Grouplist 」'
        if gids:
            groups = line.getGroups(gids)
            no = 0
            if len(groups) > 200:
                parsed_len = len(groups)//200+1
                for point in range(parsed_len):
                    for group in groups[point*200:(point+1)*200]:
                        no += 1
                        res += '\n   • %i. %s [%i]' % (no, group.name, len(group.members))
                        gnames.append(group.name)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for group in groups:
                    no += 1
                    res += '\n  • %i. %s [%i]' % (no, group.name, len(group.members))
                    gnames.append(group.name)
        else:
            res += '\n Nothing Group'
        res += '\n⌬「 Command 」'
        res += '\n * {key}Meluncur:「 Num 」'
        res += '\n * {key}Kickall:「 Num 」'
        res += '\n * {key}Cancelall:「 Num 」'
        res += '\n * {key}skill: 「 Num | name 」'
        res += '\n * {key}Ginfo:「 Num 」'
        res += '\n * {key}Infomem:「 Num 」'
        res += '\n * {key}Openqr:「 Num 」'
        res += '\n * {key}Closeqr:「 Num 」'
        res += '\n * {key}Inviteme:「 Num 」'
        res += '\n * {key}Leave:「 Num 」'
        res += '\n * {key}spamcall:「 Num 」「 Num 」'
        res += '\n * {key}unsend:「 Num 」「 Num 」'
        res += '\n * {key}mentionall:「 Num 」'
        ress.append(res)
        if cmd == 'glist':
          if msg._from in owner or msg._from in admin:	
            for res in ress:
                line.sendMessage(to,(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('out:'):
          if msg._from in owner or msg._from in admin:	
            texts = textt[6:].split(':')
            leaved = []
            if not gids:
                return line.sendMessage(to, 'Failed leave group, nothing group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in leaved:
                            line.sendMessage(to, 'Already leave group %s' % group.name)
                            continue
                        line.leaveGroup(group.id)
                        leaved.append(group.id)
                        if to not in leaved:
                            line.sendMessage(to, 'Success leave group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed leave group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in leaved:
                            line.sendMessage(to, 'Already leave group %s' % group.name)
                            continue
                        line.leaveGroup(group.id)
                        leaved.append(group.id)
                        if to not in leaved:
                            line.sendMessage(to, 'Success leave group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in leaved:
                                continue
                            line.leaveGroup(gid)
                            leaved.append(gid)
                            time.sleep(0.8)
                        if to not in leaved:
                            line.sendMessage(to, 'Success leave all group ')
                    else:
                        line.sendMessage(to, 'Failed leave group with name `%s`, name not in list ' % name)
        else:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('gpending'):
      if msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        gids = line.getGroupIdsInvited()
        gnames = []
        ress = []
        res = '⌬ Invitation List♪'
        res += '\n⌬ List:'
        if gids:
            groups = line.getGroups(gids)
            no = 0
            if len(groups) > 200:
                parsed_len = len(groups)//200+1
                for point in range(parsed_len):
                    for group in groups[point*200:(point+1)*200]:
                        no += 1
                        res += '\n %i. %s//%i' % (no, group.name, len(group.members))
                        gnames.append(group.name)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for group in groups:
                    no += 1
                    res += '\n %i. %s//%i' % (no, group.name, len(group.members))
                    gnames.append(group.name)
        else:
            res += '\n Nothing'
        res += '\n⌬ Usage : '
        res += '\n⌬ • {key}Gpending'
        res += '\n⌬ • {key}Gpending Accept <num/name/all>'
        res += '\n⌬ • {key}Gpending Reject <num/name/all>'
        ress.append(res)
        if cmd == 'gpending':
          if msg._from in admin:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('accept '):
            texts = textt[7:].split(', ')
            accepted = []
            if not gids:
                return line.sendMessage(to, 'Failed accept group, nothing invitation group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in accepted:
                            line.sendMessage(to, 'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to, 'Success accept group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed accept group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in accepted:
                            line.sendMessage(to, 'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to, 'Success accept group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in accepted:
                                continue
                            line.acceptGroupInvitation(gid)
                            accepted.append(gid)
                            time.sleep(0.8)
                        line.sendMessage(to, 'Success accept all invitation group ♪')
                    else:
                        line.sendMessage(to, 'Failed accept group with name `%s`, name not in list ♪' % name)
        elif texttl.startswith('reject '):
            texts = textt[7:].split(', ')
            rejected = []
            if not gids:
                return line.sendMessage(to, 'Failed reject group, nothing invitation group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in rejected:
                            line.sendMessage(to, 'Already reject group %s' % group.name)
                            continue
                        line.rejectGroupInvitation(group.id)
                        rejected.append(group.id)
                        line.sendMessage(to, 'Success reject group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed reject group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in rejected:
                            line.sendMessage(to, 'Already reject group %s' % group.name)
                            continue
                        line.rejectGroupInvitation(group.id)
                        rejected.append(group.id)
                        line.sendMessage(to, 'Success reject group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in rejected:
                                continue
                            line.rejectGroupInvitation(gid)
                            rejected.append(gid)
                            time.sleep(0.8)
                        line.sendMessage(to, 'Success reject all invitation group ♪')
                    else:
                        line.sendMessage(to, 'Failed reject group with name `%s`, name not in list ♪' % name)
        else:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'memberlist':
        if msg.toType == 1:
            room = line.getRoom(to)
            members = room.contacts
        elif msg.toType == 2:
            group = line.getGroup(to)
            members = group.members
        else:
            return line.sendMessage(to, 'Failed display member list, use this command only on room or group chat')
        if not members:
            return line.sendMessage(to, 'Failed display member list, no one contact')
        res = '╭───[ Member List ]'
        parsed_len = len(members)//200+1
        no = 0
        for point in range(parsed_len):
            for member in members[point*200:(point+1)*200]:
                no += 1
                res += '\n│ %i. %s' % (no, member.displayName)
                if member == members[-1]:
                    res += '\n╰───[ Member List ]'
            if res:
                if res.startswith('\n'): res = res[1:]
                line.sendMessage(to, res)
            res = ''
    elif cmd.startswith('infomem:'):
      if msg._from in owner or msg._from in admin:
                                    separate = msg.text.split(":")
                                    number = msg.text.replace(separate[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    ret_ = ""
                                    try:
                                        group = groups[int(number)-1]
                                        G = line.getGroup(group)
                                        no = 0
                                        ret_ = ""
                                        for mem in G.members:
                                           no += 1
                                           ret_ += "\n " " "+ str(no) + ". " + mem.displayName
                                        line.sendMessage(to," Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\nTotal %i Members" % len(G.members))
                                    except:
                                           pass
    elif cmd.startswith("openqr: "):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    group = groups[int(number)-1]
                                    G = line.getGroup(group)
                                    G.preventedJoinByTicket = False
                                    line.updateGroup(G)
                                    url = line.reissueGroupTicket(group)
                                    ticket = 'Sukses Remoted Commands\nOpen qr in groups {}\nlink: https://line.me/R/ti/g/{}'.format(G.name,url)
                                    line.sendMessage(to,ticket)
    elif cmd.startswith("closeqr: "):
      if msg._from in owner or msg._from in admin:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    group = groups[int(number)-1]
                                    G = line.getGroup(group)
                                    G.preventedJoinByTicket = True
                                    line.updateGroup(G)
                                    ticket = 'Sukses Remoted Commands\nClose qr in groups {}'.format(G.name)
                                    line.sendMessage(to,ticket)
    elif cmd == 'openqr':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed open qr, use this command only on group chat')
        group = line.getCompactGroup(to)
        group.preventedJoinByTicket = False
        line.updateGroup(group)
        line.sendMessage(to, 'Success mek, Status open qr group')
    elif cmd == 'closeqr':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed close qr, use this command only on group chat')
        group = line.getCompactGroup(to)
        group.preventedJoinByTicket = True
        line.updateGroup(group)
        line.sendMessage(to,'Success mek, Status close qr group')
    elif cmd.startswith('changegn '):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed change group name, use this command only on group chat')
        group = line.getCompactGroup(to)
        gname = removeCmd(text, setKey)
        if len(gname) > 50:
            return line.sendMessage(to, 'Failed change group name, the number of names cannot exceed 50')
        group.name = gname
        line.updateGroup(group)
        line.sendMessage(to, 'Success change group name to `%s`' % gname)
    elif cmd == 'changegp':
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed change group picture, use this command only on group chat')
        if to not in settings['changeGroupPicture']:
            settings['changeGroupPicture'].append(to)
            line.sendMessage(to, 'Please send the image, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
        else:
            line.sendMessage(to, 'Command already active, please send the image or type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd.startswith("leave: "):
        if msg._from in owner or msg._from in admin:
            sep = msg.text.split(":")
            number = msg.text.replace(sep[0] + ":","")
            bolo = line.getGroupIdsJoined()
            try:
                group = bolo[int(number)-1+0]
                G = line.getGroup(group)
                gid = G.id
                no = 0 + 1
                line.leaveGroup(gid)
                line.sendMessage(to,"succes leave: "+str(G.name))
            except Exception as e:
                line.sendMessage(to, str(e))
#================JS DAN BYPASS================
    elif cmd == settings['changebypass']:
      if msg._from in owner or msg._from in admin:
        if nukemode["java"] == True:
            if msg.toType == 2:
                group = line.getGroup(to)
                if group.invitee == None:
                    pends = []
                else:
                    pends = [a.mid for a in group.invitee]
                pending = []
                for x in pends:
                    if x not in settings["whitelist"]:
                        pending.append(x)
                mems = [a.mid for a in group.members]
                member = []
                for x in mems:
                    if x not in settings["whitelist"]:
                        member.append(x)
                cm = 'dual.js gid={} token={}'.format(to, line.authToken)
                for x in pending:
                    cm += ' uid={}'.format(x)
                for x in member:
                    cm += ' uik={}'.format(x)
                success = execute_js(cm)
                if success:
                        line.sendMessage(to,"Bypass Success")
                else:
                        line.sendMessage(to,"Bypass Failed >_<")
        else:
            line.sendMessage(to,"Type `javamode on` to use this command")
    elif cmd == settings['changekickall']:
      if msg._from in owner or msg._from in admin:
        if nukemode["java"] == True:
            if msg.toType == 2:
                group = line.getGroup(to)
                if group.invitee == None:
                    mem = []
                else:
                	mems = [a.mid for a in group.members]
                member = []
                for x in mems:
                    if x not in settings["whitelist"]:
                        member.append(x)
                cm = 'dual.js gid={} token={}'.format(to, line.authToken)
                for x in member:
                    cm += ' uik={}'.format(x)
                success = execute_js(cm)
                if success:
                        line.sendMessage(to,"Kickall Success")
                else:
                        line.sendMessage(to,"Kickall Failed >_<")             
        else:
            line.sendMessage(to,"Type `javamode on` to use this command")
    elif cmd == settings['changecancelall']:
      if msg._from in owner or msg._from in admin:
        if nukemode["java"] == True:
            if msg.toType == 2:
                group = line.getGroup(to)
                if group.invitee == None:
                    pends = []
                else:
                    pends = [a.mid for a in group.invitee]
                pending = []
                for x in pends:
                    if x not in settings["whitelist"]:
                        pending.append(x)
                cm = 'dual.js gid={} token={}'.format(to, line.authToken)
                for x in pending:
                    cm += ' uid={}'.format(x)  
                    success = execute_js(cm)
                if success:
                        line.sendMessage(to,"Cancelall Success")
                else:
                        line.sendMessage(to,"Cancelall Failed >_<")
        else:
            line.sendMessage(to,"Type `javamode on` to use this command")
    elif cmd.startswith("meluncur: "):
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + ":","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                pends = []
            else:
                pends = [a.mid for a in G.invitee]
            pending = []
            for x in pends:
                if x not in settings["whitelist"]:
                    pending.append(x)
            mems = [a.mid for a in G.members]
            member = []
            for x in mems:
                if x not in settings["whitelist"]:
                    member.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in pending:
                cm += ' uid={}'.format(x)
            for x in member:
                cm += ' uik={}'.format(x)
            success = execute_js(cm)
            if success:
                    line.sendMessage(to,"Remote Bypass Success")
            else:
                    line.sendMessage(to,"Remote Bypass Failed >_<")
    elif cmd.startswith("kickall: "):
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + ":","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                pends = []
            else:
            	mems = [a.mid for a in G.members]
            member = []
            for x in mems:
                if x not in settings["whitelist"]:
                    member.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in member:
                cm += ' uik={}'.format(x)
            success = execute_js(cm)
            if success:
                    line.sendMessage(to,"Remote Kickall Success")
            else:
                    line.sendMessage(to,"Remote Kickall Failed >_<")
    elif cmd.startswith("cancelall: "):
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + ":","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                pends = []
            else:
                pends = [a.mid for a in G.invitee]
            pending = []
            for x in pends:
                if x not in settings["whitelist"]:
                    pending.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in pending:
                cm += ' uid={}'.format(x)  
                success = execute_js(cm)
            if success:
                    line.sendMessage(to,"Remote Cancelall Success")
            else:
                    line.sendMessage(to,"Remote Cancelall Failed >_<")
    elif cmd.startswith("skill: "):
      if msg._from in owner or msg._from in admin:
        if msg.toType == 2:
            stopcoli = cmd.split(": ")[1]
            sam = stopcoli.split(" | ")
            grup = sam[0]
            nama = sam[1]
            name = nama.split(',')
            if name == "":pass
            else:
                groups = line.getGroupIdsJoined()
                if groups is not None:
                    if int(grup) <= len(groups):
                        groupid = groups[int(grup) - 1]
                        Z = line.getGroup(groupid)
                        A = [a.mid for a in Z.members]
                        if Z.invitee == None:B = []
                        else:B = [a.mid for a in Z.invitee]
                        pend = []
                        mem = []
                        for nama in name:
                            if Z.invitee != None:
                                for pendingan in B:
                                    contact = line.getContact(pendingan)
                                    if contact.displayNameOverridden is not None:
                                        if nama in contact.displayNameOverridden.lower():
                                            if pendingan != myMid:
                                                pend.append(contact.mid)
                                        else:
                                            if nama in contact.displayName.lower():
                                                if pendingan != myMid:
                                                    pend.append(contact.mid)
                                    else:
                                        if nama in contact.displayName.lower():
                                            if pendingan != myMid:
                                                pend.append(contact.mid)
                            for member in A:
                                contact = line.getContact(member)
                                if contact.displayNameOverridden is not None:
                                    if nama in contact.displayNameOverridden.lower():
                                        if member != myMid:
                                            mem.append(contact.mid)
                                    else:
                                        if nama in contact.displayName.lower():
                                            if member != myMid:
                                                mem.append(contact.mid)
                                else:
                                    if nama in contact.displayName.lower():
                                        if member != myMid:
                                            mem.append(contact.mid)
                        try:
                            imnoob = 'dual.js gid={} token={}'.format(groupid, line.authToken)
                            if pend == [] and mem == []:line.sendMessage(receiver,"{} not found".format(nama))
                            else:
                                for abc in pend:imnoob += ' uid={}'.format(abc)
                                for aca in mem:imnoob += " uik={}".format(aca)
                                success = execute_js(imnoob)
                                if success:line.sendMessage(to, "Success kill name {} in ".format(nama) + Z.name)
                                else:line.sendMessage(to, "Detected an error")
                        except Exception as e:line.sendMessage(to,str(e))
                else:line.sendMessage(to, "Your groups are below that numbers")
#========owner
    elif cmd.startswith("addadmin "):
      if msg._from in owner:
         key = eval(msg.contentMetadata["MENTION"])
         key["MENTIONEES"][0]["M"]
         targets = []
         for x in key["MENTIONEES"]:
              targets.append(x["M"])
         for target in targets:
                try:
                    if target not in admin:
                        admin.append(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Added To Admin",[target])
                    else:
                        line.sendMentionV2(to,"User @! Already In Admin",[target])
                except:
                    pass
    elif cmd.startswith("deladmin "):
        if msg._from in owner:
            key = eval(msg.contentMetadata["MENTION"])
            key["MENTIONEES"][0]["M"]
            targets = []
            for x in key["MENTIONEES"]:
                targets.append(x["M"])
            for target in targets:
                try:
                    if target in admin:
                        admin.remove(target)
                        line.sendMentionV2(to,"「 @! 」\nUser Deleted To Admin",[target])
                    else:
                        line.sendMentionV2(to,"User @! Not In Admin",[target])
                except:
                    pass
#========KICK========           
    elif cmd.startswith('invite '):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed invite member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                except TalkException as talk_error:
                    return line.sendMessage(to, 'Failed invite members, the reason is `%s`' % talk_error.reason)
                time.sleep(0.8)
        else:
            line.sendMessage(to,)
    elif cmd.startswith(settings['changekick']):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                except:
                    line.sendMessage(to,"Limited")
    elif cmd.startswith('slain '):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed vultra kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                    line.cancelGroupInvitation(to, [mid])
                    line.inviteIntoGroup(to, [mid])
                except TalkException as talk_error:
                    return line.sendMessage(to, 'Failed vultra kick members, the reason is `%s`' % talk_error.reason)
        else:
            line.sendMessage(to,)
    elif cmd == settings["changekickr"]:
      if msg._from in owner or msg._from in admin:
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            line.kickoutFromGroup(to, [bb._from])
                            break
                else:
                    line.sendMessage(to, 'you must reply the message')
    elif cmd == settings["changeinvites"]:
      if msg._from in owner or msg._from in admin:
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            line.findAndAddContactsByMid(bb._from)
                            line.inviteIntoGroup(to, [bb._from])
                            break
                else:
                    line.sendMessage(to, 'you must reply the message')
    elif cmd.startswith('kickjs '):
      if msg._from in owner or msg._from in admin: 
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                imnoob = 'dual.js gid={} token={}'.format(to, line.authToken)
                                for x in key["MENTIONEES"]:
                                    if x["M"] not in settings["whitelist"]:
                                        imnoob += " uik={}".format(x["M"])
                                execute_js(imnoob)
    elif cmd.startswith(seni["ckill"]):
      if msg._from in owner or msg._from in admin:
        if msg.toType != 2: return line.sendMessage(to, 'Failed kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                imnoob = 'kickall.js gid={} token={}'.format(to, line.authToken)
                if mid == myMid:
                    continue
                try:
                    imnoob += " uik={}".format(mid)
                    execute_js(imnoob)
                except:
                    line.sendMessage(to,"Limited")
        else:
            sep = removeCmd(text,setKey)
            group = line.getGroup(to)
            targets = []
            targets2 = []
            if group.invitee:
                for i in group.invitee:
                    if line.getContact(i.mid).displayNameOverridden != None:
                        if sep.lower() in line.getContact(i.mid).displayNameOverridden.lower():
                            targets2.append(i.mid)
                    else:
                        if sep.lower() in line.getContact(i.mid).displayName.lower():
                            targets2.append(i.mid)
            for i in group.members:
                if line.getContact(i.mid).displayNameOverridden != None:
                    if sep.lower() in line.getContact(i.mid).displayNameOverridden.lower():
                        targets.append(i.mid)
                else:
                    if sep.lower() in line.getContact(i.mid).displayName.lower():
                        targets.append(i.mid)
            if targets2 != []:
                exc = f"dual.js gid={to} token={line.authToken} app=desktopwin"
                for i in targets2:
                    exc += f" uid={i}"
                for i in targets:
                    exc += f" uik={i}"
                execute_js(exc)
            if targets != []:
                exc = f"kickall.js gid={to} token={line.authToken} app=desktopwin"
                for i in targets:
                    exc += f" uik={i}"
                execute_js(exc)
    elif cmd.startswith(seni["cinv"]):
      if msg._from in owner or msg._from in admin:
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ", "")
                            if name == '':
                                return
                            friend = line.getAllContactIds()
                            list = []
                            for teman in friend:
                                contact = line.getContact(teman)
                                if contact.displayNameOverridden is not None:
                                    if name in contact.displayNameOverridden.lower():
                                        list.append(contact.mid)
                                    else:
                                        if name in contact.displayName.lower():
                                            list.append(contact.mid)
                                else:
                                    if name in contact.displayName.lower():
                                        list.append(contact.mid)
                            if list:
                                for a in list:
                                    line.inviteIntoGroup(to, [a])
                            else:
                                line.sendMessage(to, "'{}' not found".format(name))

    elif cmd == "purge":
      if msg._from in owner or msg._from in admin: 
                            if msg.toType == 2:
                                group = line.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                for tag in settings["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    line.sendMessage(to, "Blacklist not detected!")
                                    return
                                for jj in lists:
                                    line.kickoutFromGroup(to,[jj])
                                line.sendMessage(to,"yuhuuuu")
    elif cmd == "purgejs":
      if msg._from in owner or msg._from in admin: 
                            if msg.toType == 2:
                                group = line.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                imnoob = 'dual.js gid={} token={}'.format(to, line.authToken)
                                for tag in settings["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    line.sendMessage(to, "Blacklist not detected!")
                                    return
                                for jj in lists:
                                        imnoob += " uik={}".format(jj)
                                execute_js(imnoob)
                                line.sendMessage(to,"Blacklist has been purge")
    elif cmd.startswith("inviteme: "):
      if msg._from in owner or msg._from in admin: 
                                separate = text.split(" ")
                                num = text.replace(separate[0] + " ","")
                                groups = line.getGroupIdsJoined()
                                if groups is not None:
                                    if int(num) <= len(groups):
                                        groupid = groups[int(num) - 1]
                                        group = line.getGroup(groupid)
                                        try:
                                            line.findAndAddContactsByMid(msg._from)
                                            line.inviteIntoGroup(groupid,[msg._from])
                                            line.sendMessage(to, "「Done invite to " + group.name + "」")
                                        except Exception as e:
                                            line.sendMessage(to, str(e) + "\nMaybe, already into the group / Limit for invite")                          
#================Feature================
    elif cmd.startswith('resendchat '):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        G = line.getGroup(to)
        if texttl == 'on':
            if settings["unsendMessage"]:
                line.sendMessage(to, 'Resend Chat already active')
            else:
                settings["unsendMessage"] = True
                line.sendMessage(to, '「 Notifikasi 」\nResend Chat berhasil diaktifkan\nDi Group ' +  str(G.name))
        elif texttl == 'off':
            if not settings["unsendMessage"]:
                line.sendMessage(to, 'Resend Chat already deactive')
            else:
                settings["unsendMessage"] = False
                line.sendMessage(to, '「 Notifikasi 」\nResend Chat berhasil dimatikan\nDi Group ' +  str(G.name))
    elif cmd.startswith('appname'):
      if msg._from in owner or msg._from in admin:
      	line.sendMessage(to, "Appname :\n" + str(line.server.APP_NAME))
    elif cmd.startswith("cek "):
      if msg._from in owner or msg._from in admin:
        sep = text.split(" ")
        itil = text.replace(sep[0] + " ","")
        line.sendMessage(msg.to, None, contentMetadata={'mid': itil}, contentType=13)
    elif cmd.startswith('uns '):
      if msg._from in owner or msg._from in admin:
        sep = msg.text.split(" ")
        args = msg.text.replace(sep[0] + " ","")
        mes = int(sep[1])
        M = line.getRecentMessagesV2(to, 1001)
        MId = []
        for ind,i in enumerate(M):
            if ind == 0:
                pass
            else:
                if i._from == line.profile.mid:
                    MId.append(i.id)
                    if len(MId) == mes:
                        break
        def unsMes(id):
            line.unsendMessage(id)
        for i in MId:
            thread1 = threading.Thread(target=unsMes, args=(i,))
            thread1.daemon = True
            thread1.start()
            thread1.join()
    elif cmd.startswith('unsend: '):
      if msg._from in owner or msg._from in admin:
        sep = text.split(" ")
        num = int(sep[1])
        numb = int(sep[2])
        sep2 = text.replace(sep[0] + ' ','')
        text = sep2.replace(sep[1] + ' ','')
        groups = line.getGroupIdsJoined()
        group = groups[int(num) - 1]
        G = line.getGroup(group)
        M = line.getRecentMessagesV2(group, 1001)
        MId = []
        for ind,i in enumerate(M):
            if ind == 0:
                pass
            else: 
                if i._from == line.profile.mid:
                    MId.append(i.id)
                    if len(MId) == numb:
                        break
        def unsMes(id):
            line.unsendMessage(id)
        for i in MId:
            thread1 = threading.Thread(target=unsMes, args=(i,))
            thread1.daemon = True
            thread1.start()
            thread1.join()
        line.unsendMessage(msg.id)
        res = 'Sukses Remoted Commands'
        res += '\nTotal unsend {} message.'.format(len(MId))
        res += '\nIn Group :' + G.name
        line.sendMessage(to, res)
    elif cmd.startswith("spamcall "):
      if msg._from in owner or msg._from in admin:
                                if msg.toType == 2:
                                    sep = text.split(" ")
                                    strnum = text.replace(sep[0] + " ","")
                                    num = int(strnum)
                                    line.sendMessage(to, "Succesfully Spam Call to Group")
                                    for var in range(0,num):
                                       group = line.getGroup(to)
                                       members = [mem.mid for mem in group.members]
                                       line.acquireGroupCallRoute(to)
                                       time.sleep(0.5)
                                       line.inviteIntoGroupCall(to, contactIds=members)
    elif cmd.startswith('autoadd'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Auto Add♪'
        res += '\nStatus : ' + bool_dict[settings['autoAdd']['status']][1]
        res += '\nReply : ' + bool_dict[settings['autoAdd']['reply']][0]
        res += '\nReply Message : ' + settings['autoAdd']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoAdd'
        res += '\n	 › {key}AutoAdd <on/off>'
        res += '\n	 › {key}AutoAdd Reply <on/off>'
        res += '\n	 › {key}AutoAdd <message>'
        if cmd == 'autoadd':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoAdd']['status']:
                line.sendMessage(to, 'Autoadd already active')
            else:
                settings['autoAdd']['status'] = True
                line.sendMessage(to, 'Success activated autoadd')
        elif texttl == 'off':
            if not settings['autoAdd']['status']:
                line.sendMessage(to, 'Autoadd already deactive')
            else:
                settings['autoAdd']['status'] = False
                line.sendMessage(to, 'Success deactivated autoadd')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoAdd']['reply']:
                    line.sendMessage(to, 'Reply message autoadd already active')
                else:
                    settings['autoAdd']['reply'] = True
                    line.sendMessage(to, 'Success activate reply message autoadd')
            elif cond[1].lower() == 'off':
                if not settings['autoAdd']['reply']:
                    line.sendMessage(to, 'Reply message autoadd already deactive')
                else:
                    settings['autoAdd']['reply'] = False
                    line.sendMessage(to, 'Success deactivate reply message autoadd')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autoAdd']['message'] = textt
            line.sendMessage(to, 'Success change autoadd message to `%s`' % textt)
    elif cmd.startswith('autocomment'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Auto Comment♪'
        res += '\nStatus : ' + bool_dict[settings['autokomen']['status']][1]
        res += '\nReply Message : ' + settings['autokomen']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoLike'
        res += '\n	 › {key}Autocomment <on/off>'
        res += '\n	 › {key}Autocomment <message>'
        if cmd == 'autocomment':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autokomen']['status']:
                line.sendMessage(to, 'aktip dahhh')
            else:
                settings['autokomen']['status'] = True
                line.sendMessage(to, 'Success activated autocomment')
        elif texttl == 'off':
            if not settings['autokomen']['status']:
                line.sendMessage(to, 'gaaktip dahhh')
            else:
                settings['autokomen']['status'] = False
                line.sendMessage(to, 'Success deactivated autocomment')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autokomen']['reply']:
                    line.sendMessage(to, 'Reply message autocomment already active')
                else:
                    settings['autokomen']['reply'] = True
                    line.sendMessage(to, 'Success activate reply message autocomment')
            elif cond[1].lower() == 'off':
                if not settings['autokomen']['reply']:
                    line.sendMessage(to, 'Reply message autocomment already line.sendMessage')
                else:
                    settings['autokomen']['reply'] = False
                    line.sendMessage(to, 'Success deactivate reply message autocomment')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autokomen']['message'] = textt
            line.sendMessage(to, 'Success change autocomment message to `%s`' % textt)
    elif cmd.startswith('autolike'):
      if msg._from in owner or msg._from in admin:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Auto Like ♪'
        res += '\nStatus : ' + bool_dict[settings['autolike']['status']][1]
        res += '\nReply Message : ' + settings['autolike']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoComment'
        res += '\n	 › {key}AutoLike <on/off>'
        res += '\n	 › {key}AutoLike <message>'
        if cmd == 'autolike':
          if msg._from in owner or msg._from in admin:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autolike']['status']:
                line.sendMessage(to, 'aktip dahhh')
            else:
                settings['autolike']['status'] = True
                line.sendMessage(to, 'Success activated autolike')
        elif texttl == 'off':
            if not settings['autolike']['status']:
                line.sendMessage(to, 'gaaktip dahhh')
            else:
                settings['autolike']['status'] = False
                line.sendMessage(to, 'Success deactivated autolike')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autolike']['reply']:
                    line.sendMessage(to, 'Reply message autolike already active')
                else:
                    settings['autolike']['reply'] = True
                    line.sendMessage(to, 'Success activate reply message autolike')
            elif cond[1].lower() == 'off':
                if not settings['autolike']['reply']:
                    line.sendMessage(to, 'Reply message autolike already deactive')
                else:
                    settings['autolike']['reply'] = False
                    line.sendMessage(to, 'Success deactivate reply message autolike')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autolike']['message'] = textt
            line.sendMessage(to, 'Success change autolike message to `%s`' % textt)
    elif cmd.startswith('spamcall: '):
      if msg._from in owner or msg._from in admin:
        sep = text.split(" ")
        num = int(sep[1])
        numb = int(sep[2])
        sep2 = text.replace(sep[0] + ' ','')
        text = sep2.replace(sep[1] + ' ','')
        groups = line.getGroupIdsJoined()
        group = groups[int(num) - 1]
        G = line.getGroup(group)
        line.sendMessage(to, "Succesfully Spam Call to Group: " + G.name)
        for var in range(0,numb):
            G = line.getGroup(group)
            members = [mem.mid for mem in G.members]
            line.acquireGroupCallRoute(group)
            time.sleep(0.8)
            line.inviteIntoGroupCall(group, contactIds=members)
    elif cmd.startswith("spamtag "):
      if msg._from in owner or msg._from in admin:
            dan = text.split(" ")
            num = int(dan[1])
            text = " Spamtag \nBerhasil {} Spamtag".format(str(dan[1]))
            if 'MENTION' in msg.contentMetadata.keys()!= None:
                names = re.findall(r'@(\w+)', text)
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                lists = []
                for mention in mentionees:
                    if mention["M"] not in lists:
                        lists.append(mention["M"])
                for ls in lists:
                    for var in range(0,num):
                        sendMention(to, "@!", [ls])
                line.sendMessage(to, text)
                line.sendMessage(to, str(text.replace(spam[0] + " " + spam[1] + " ","")))
def executeOp(op):
    try:
        print ('++ Operation : ( %i ) %s' % (op.type, OpType._VALUES_TO_NAMES[op.type].replace('_', ' ')))
        if op.type == 5:
           if settings['autoAdd']['status']:
#                 line.findAndAddContactsByMid(op.param1)
            if settings['autoAdd']['reply']:
                if '@!' not in settings['autoAdd']['message']:
                    line.sendMessage(op.param1, settings['autoAdd']['message'])
                else:
                    line.sendMentionV2(op.param1, settings['autoAdd']['message'], [op.param1])
        if op.type == 11 or op.type == 122:
            if op.param1 in settings["protectqr"]:
                try:
                    if line.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                            settings["blacklist"].append(op.param2)
                            line.reissueGroupTicket(op.param1)
                            X = line.getCompactGroup(op.param1)
                            X.preventedJoinByTicket = True
                            line.updateGroup(X)
                            line.kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass
        if op.type == 13 or op.type == 124:
            if settings['autoJoin']['status'] and myMid in op.param3:
                mude00 = threading.Thread(target=join, args=(op.param1,)).start()
                if settings['autoJoin']['reply']:
                    if '@!' not in settings['autoJoin']['message']:
                        line.sendMessage(op.param1, settings['autoJoin']['message'])
                    else:
                        line.sendMentionV2(op.param1, settings['autoJoin']['message'], [op.param2])
            if op.param3 in settings["blacklist"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        anu = line.getCompactGroup(op.param1)
                        if anu.invitee is not None:
                            pipo = [a.mid for a in anu.invitee]
                            for target in pipo:
                                if target in op.param3:
                                    try:
                                        line.kickoutFromGroup(op.param1,[op.param2])
                                        line.cancelGroupInvitation(op.param1,[target])
                                    except:
                                        pass
                    except:pass
                else:pass
                if op.param2 not in settings["blacklist"]:
                    if op.param2 not in settings["whitelist"]:
                        settings['blacklist'].append(op.param2)
                    else:pass
                else:pass
            if op.param1 in settings["protectinvite"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings['blacklist'].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])                                         
                        except:pass
                        mbul = line.getGroup(op.param1)
                        no = 0
                        for a in mbul.invitee:
                            if a.mid in op.param3:
                                if no > 10:pass
                                else:
                                    try:
                                        no = (no+1)
                                        line.cancelGroupInvitation(op.param1,[a.mid])
                                        time.sleep(0.04)
                                    except:pass
                        for b in mbul.members:
                            if b.mid in op.param3:
                                try:
                                    line.kickoutFromGroup(op.param1,[b.mid])
                                except:pass
                    except:pass
                else:pass
        if op.type == 25 or op.type == 26:
            print ("++ Operation : ( [25:26]) AUTOLIKE MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
            if msg.contentType == 16:
            	if msg.toType in (2,1,0):
                    if settings['autokomen']['status']:
                        if msg.contentMetadata['serviceType'] in ['GB', 'NT', 'MH']:
                            if msg.contentMetadata['serviceType'] in ['GB', 'NT']:
                                contact = line.getContact(sender)
                                author = contact.displayName
                            else:
                                author = msg.contentMetadata['serviceName']
                            posturl = msg.contentMetadata['postEndUrl']
                            rep = posturl.replace("line://home/post?userMid=","")
                            sep = rep.split("&postId=")
                            line.createComment(sender, sep[1], settings['autokomen']['message'])
                    if settings['autolike']['status']:
                        if msg.contentMetadata['serviceType'] in ['GB', 'NT', 'MH']:
                            if msg.contentMetadata['serviceType'] in ['GB', 'NT']:
                                contact = line.getContact(sender)
                                author = contact.displayName
                            else:
                                author = msg.contentMetadata['serviceName']
                            posturl = msg.contentMetadata['postEndUrl']
                            line.sendMessage(to,settings['autolike']['message'])
                            rep = posturl.replace("line://home/post?userMid=","")
                            sep = rep.split("&postId=")
                            line.likePost(sender, sep[1], 1001)
        if op.type == 13 or op.type == 124:
            if op.param3 in myMid:
                if joinpurge["purgee"] == True:
                            line.acceptGroupInvitation(op.param1)
                            group = line.getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.members]
                            matched_list = []
                            imnoob = 'kickall.js gid={} token={}'.format(op.param1, line.authToken)
                            for tag in settings['blacklist']:
                                matched_list+=filter(lambda str: str == tag, gMembMids)
                            if matched_list == []:
                                line.kickoutFromGroup(op.param1,[tag])
                                return
                            for jj in matched_list:
                                imnoob += " uik={}".format(jj)
                            execute_js(imnoob)
            if op.param3 in settings["blacklist"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        anu = line.getCompactGroup(op.param1)
                        if anu.invitee is not None:
                            pipo = [a.mid for a in anu.invitee]
                            for target in pipo:
                                if target in op.param3:
                                    try:
                                        line.kickoutFromGroup(op.param1,[op.param2])
                                        line.cancelGroupInvitation(op.param1,[target])
                                    except:
                                        pass
                    except:pass
                else:pass
                if op.param2 not in settings["blacklist"]:
                    if op.param2 not in settings["whitelist"]:
                        settings['blacklist'].append(op.param2)
                    else:pass
                else:pass
            if op.param1 in settings["protectinvite"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings['blacklist'].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])                                         
                        except:pass
                        mbul = line.getGroup(op.param1)
                        no = 0
                        for a in mbul.invitee:
                            if a.mid in op.param3:
                                if no > 10:pass
                                else:
                                    try:
                                        no = (no+1)
                                        line.cancelGroupInvitation(op.param1,[a.mid])
                                        time.sleep(0.04)
                                    except:pass
                        for b in mbul.members:
                            if b.mid in op.param3:
                                try:
                                    line.kickoutFromGroup(op.param1,[b.mid])
                                except:pass
                    except:pass
                else:pass
        if op.type == 13:
           if wait["selfbot1"] == True:
               if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                  random.choice(KAC).cancelGroupInvitation(op.param1,[op.param3])
                  random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
        if op.type == 15 or op.type == 128:
            if settings['greet']['leave']['status']:
                if '@!' not in settings['greet']['leave']['message']:
                    line.sendMessage(op.param1, settings['greet']['leave']['message'].format(name=line.getCompactGroup(op.param1).name))
                else:
                    line.sendMentionV2(op.param1, settings['greet']['leave']['message'].format(name=line.getCompactGroup(op.param1).name), [op.param2])
        if op.type == 17 or op.type == 130:
            if settings['greet']['join']['status']:
                if '@!' not in settings['greet']['join']['message']:
                    line.sendMessage(op.param1, settings['greet']['join']['message'].format(name=line.getCompactGroup(op.param1).name))
                else:
                    line.sendMentionV2(op.param1, settings['greet']['join']['message'].format(name=line.getCompactGroup(op.param1).name), [op.param2])
            if op.param2 in settings["blacklist"]:
                try:
                    group = line.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    line.kickoutFromGroup(op.param1,[op.param2])
                    line.updateGroup(group)
                    group.preventedJoinByTicket = True
                    line.updateGroup(group)
                except Exception as e:
                    group = line.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    line.kickoutFromGroup(op.param1,[op.param2])
                    line.updateGroup(group)
            if op.param1 in settings["protectjoin"]:
                if op.param2 not in settings["whitelist"]:
                    settings["blacklist"].append(op.param2)
                    try:
                        if op.param3 not in settings["blacklist"]:
                        	line.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 19 or op.type == 133:
          if op.param3 in myMid:
            if op.param2 not in settings["blacklist"]:
                settings["blacklist"].append(op.param2)
                group = "u9b6db671badc05e225fd489e0a72a3e3" #mid gc dapat di lihat di groupinfo
                nameGroup = line.getGroup(op.param1).name
                jam = pytz.timezone("Asia/Jakarta")
                jamSek = datetime.now(tz=jam)
                jamm = datetime.strftime(jamSek, '%d-%m-%Y')
                jammm = datetime.strftime(jamSek,'%H:%M:%S')
                contact = line.getContact(myMid)
                kiker = line.getContact(op.param2)
                res = "╭───[ Notifikasi Kick ]"
                res += "\n├ In Group: {}".format(nameGroup)
                res += "\n├ Date: {}".format(jamm)
                res += "\n├ Time: {}".format(jammm)
                res += "\n├ Victim : {}".format(contact.displayName)
                res += "\n├ Kicker: {}".format(kiker.displayName)
                res += "\n╰───[ Team TCR™♪ ]"
                data = {
                                           "type": "text",
                                           "text": "{}".format(str(res)),
                                           "sentBy": {
                                           "label": "{}".format(line.getContact(myMid).displayName),
                                           "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                                           "linkUrl": "https://line.me/ti/p/yWhS9D2xpT",
                                         }
                                     }
                sendTemplate(group, data)
                line.sendContact(group, op.param2)
          if op.param3 in settings["whitelist"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in admin:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in owner:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param1 in settings["protectkick"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings["blacklist"].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])
                        except:pass
                    except:pass
        if op.type == 32 or op.type == 126:
          if op.param3 in settings["whitelist"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in admin:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param3 in owner:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param1 in settings["protectcancel"]:
                if op.param2 not in owner and op.param2 not in admin and op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings['blacklist'].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])
                        except:pass
                    except:pass
        if op.type == 55:
            if op.param2 in settings["blacklist"]:
                if joinpurge["purgebl"] == True:
                    if op.param2 not in settings["whitelist"]:
                        line.kickoutFromGroup(op.param1,[op.param2])

        if op.type == 55:
            if op.param1 in read["readPoint"]:
                if op.param2 not in read["readMember"][op.param1]:
                    read["readMember"][op.param1].append(op.param2)
        
        if op.type == 55:
            if op.param1 in lurking:
                if lurking[op.param1]['status'] and op.param2 not in lurking[op.param1]['members']:
                    lurking[op.param1]['members'].append(op.param2)
                    if lurking[op.param1]['reply']['status']:
                        if '@!' not in lurking[op.param1]['reply']['message']:
                            line.sendMessage(op.param1, lurking[op.param1]['reply']['message'])
                        else:
                            line.sendMentionV2(op.param1, lurking[op.param1]['reply']['message'], [op.param2])
            try:
                Name = line.getContact(op.param2).mid
                group = line.getGroup(op.param1).name
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                hr = timeNow.strftime("%A")
                bln = timeNow.strftime("%m")
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): bln = bulan[k-1]
                readTime = timeNow.strftime('%H.%M')
                readTime2 = hr
                readTime3 = timeNow.strftime('%d') + "-" + bln + "-" + timeNow.strftime('%Y')
                lastseen["username"][Name] = "was lastseen\nin group ' " + group + " '\nat time " + readTime + " WIB\non " + readTime2 + ", " + readTime3
                lastseen['find'][op.param2] = True

                if cctv['cyduk'][op.param1]==True:
                    if op.param1 in cctv['point']:
                        pelaku = op.param2
                        kontak = line.getContact(op.param2)
                        text = settings["defaultReplyReader"]
                        Name = line.getContact(op.param2).displayName
                        if Name in cctv['sidermem'][op.param1]:
                            pass
                        else:
                                cctv['sidermem'][op.param1] += "\n> " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        line.sendMessageMusic(op.param1, kontak.displayName, 'sider puskun aja😜', 'line.me/ti/p/~mdz-', "https://obs.line-apps.com/os/p/{}".format(str(kontak.mid)))
                                        #sendMention(op.param1, "Kak @! jelek, sider mulu",[op.param2])
                                        #line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + line.getContact(op.param2).picturePath)
                                        #sendReader(op.param1,pelaku,'Read')
                                    else:
                                        line.sendMessageMusic(op.param1, kontak.displayName, 'sider jomblo ya😜', 'line.me/ti/p/~mdz-', "https://obs.line-apps.com/os/p/{}".format(str(kontak.mid)))
                                        #sendMention(op.param1, "Kak @! sider mulu, jomblo ya ka?",[op.param2])
                                        #line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + line.getContact(op.param2).picturePath)
                                        #sendReader(op.param1,pelaku,'Read')
                                else:
                                    line.sendMessageMusic(op.param1, kontak.displayName, 'jadi sider biar apa😒', 'line.me/ti/p/~mdz-', "https://obs.line-apps.com/os/p/{}".format(str(kontak.mid)))
                                    #sendMention(op.param1, "Kak @! Jangan Sider dong",[op.param2])
                                    #line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + line.getContact(op.param2).picturePath)
                                    #sendReader(op.param1,pelaku,'Read')
                    else:
                        pass
                else:
                    pass
            except:
                pass
        if op.type == 55:
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = line.getContact(op.param2)
                    pesan = tailah["siderPesan"]
                    data = {
                        "type": "flex",
                        "altText": "{} Send Flex".format(line.getProfile().displayName),
                        "contents": {
                            "type": "bubble",
                            "styles": {
                                "header": {"backgroundColor": "#000000"},
                                "hero": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"},
                                "footer": {"backgroundColor": "#000000", "separator": True, "separatorColor": "#FFFFFF"}
                            },
                            "header": {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "𝗦𝗜𝗗𝗘𝗥 𝗠𝗘𝗠𝗕𝗘𝗥𝗦",
                                        "align": "center",
                                        "weight": "bold",
                                        "color": "#FFFFFF",
                                        "size": "sm"
                                    }
                                ]
                            },
                            "hero": {
                                "type": "image",
                                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                "size": "xl",
                                "margin":"xl",
                                "action": {
                                    "type": "uri",
                                    "uri": "line://ti/p/~tcrtm"
                                }
                            },
                            "body": {
                                "type": "box",
                                "layout": "vertical",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "vertical",
                                        "margin": "lg",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "hy kak {}".format(contact.displayName),
                                                        "align": "center",
                                                        "weight": "bold",
                                                        "color": "#000000",
                                                        "size": "sm",
                                                        "flex": 0
                                                    }
                                                ]
                                            },
                                            {
                                                "type": "box",
                                                "layout": "horizontal",
                                                "spacing": "sm",
                                                "contents": [
                                                    {
                                                        "type": "text",
                                                        "text": "{}".format(pesan),
                                                        "align": "center",
                                                        "weight": "bold",
                                                        "color": "#000000",
                                                        "size": "sm",
                                                        "flex": 0
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            },
                            "footer": {
                                "type": "box",
                                "layout": "vertical",
                                "spacing": "sm",
                                "contents": [
                                    {
                                        "type": "box",
                                        "layout": "baseline",
                                        "contents": [
                                            {
                                                "type": "icon",
                                                "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                                "size": "md"
                                            },
                                            {
                                                "type": "text",
                                                "text": gwcool["squad"],
                                                "align": "center",
                                                "color": "#FFFFFF",
                                                "size": "sm"
                                            },
                                            {
                                                "type": "spacer",
                                                "size": "xl",
                                            }
                                        ]
                                    }
                                ]
                            }
                        }
                    }
                    sendTemplate(op.param1, data)
                
            if op.param1 in read["readPoint"]:
                _name = line.getContact(op.param2).displayName
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                read["readMember"][op.param1][op.param2] = str(_name) + str(timeHours)
        if op.type == 25:
            print ("++ Operation : ( 25 ) SEND MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
                if text.lower() == 'rechat':
                    line.removeAllMessages(op.param2)
                    line.sendMessage(to, "Allchat deleted")
        if op.type in [22,24]:
            line.sendMessage(op.param1,"Jangan Invite MC kontol!!")
            line.leaveRoom(op.param1)
        if op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            cmd      = command(text)
            setKey   = settings['setKey']['key'] if settings['setKey']['status'] else ''
            if text in tmp_text:
                return tmp_text.remove(text)
            if msg.contentType == 0:
                if '/ti/g/' in text and settings['autoJoin']['ticket']:
                    regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = regex.findall(text)
                    tickets = []
                    gids = line.getGroupIdsJoined()
                    for link in links:
                        if link not in tickets:
                            tickets.append(link)
                    for ticket in tickets:
                        try:
                            group = line.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            line.sendMessage(to, 'I\'m already on group ' + group.name)
                            continue
                        line.acceptGroupInvitationByTicket(group.id, ticket)
                        if settings['autoJoin']['reply']:
                            if '@!' not in settings['autoJoin']['message']:
                                line.sendMessage(to, settings['autoJoin']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoJoin']['message'], [sender])
                        line.sendMessage(to, 'Success join to group ' + group.name)
                try:
                    executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey)
                except TalkException as talk_error:
                    logError(talk_error)
                    if talk_error.code in [7, 8, 20]:
                        sys.exit(1)
                    line.sendMessage(to, 'Execute command error, ' + str(talk_error))
                    time.sleep(3)
                except Exception as error:
                    logError(error)
                    line.sendMessage(to, 'Execute command error, ' + str(error))
                    time.sleep(3)
            elif msg.contentType == 7: # Content type is sticker
                if settings['checkSticker']:
                    res = 'Sticker Info'
                    res += '\n Sticker ID : ' + msg.contentMetadata['STKID']
                    res += '\n Sticker Packages ID : ' + msg.contentMetadata['STKPKGID']
                    res += '\n Sticker Version : ' + msg.contentMetadata['STKVER']
                    res += '\n Sticker Link : line://shop/detail/' + msg.contentMetadata['STKPKGID']
                    line.sendMessage(to, parsingRes(res))
            elif msg.contentType == 1: # Content type is image
                if settings['changePictureProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/picture.jpg')
                    line.updateProfilePicture(path)
                    line.sendMessage(to, 'Success change picture profile')
                    settings['changePictureProfile'] = False
                elif settings['changeCoverProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/cover.jpg')
                    line.updateProfileCover(path)
                    line.sendMessage(to, 'Success change cover profile')
                    settings['changeCoverProfile'] = False
                elif to in settings['changeGroupPicture'] and msg.toType == 2:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/grouppicture.jpg')
                    line.updateGroupPicture(to, path)
                    line.sendMessage(to, 'Success change group picture')
                    settings['changeGroupPicture'].remove(to)
            elif msg.contentType == 2: #content type video
                if settings["changevp"] == True:
                    contact = line.getProfile()
                    pict = "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                    path = line.downloadFileURL(pict)
                    path1 = line.downloadObjectMsg(msg_id)
                    settings["changevp"] = False
                    changevideopp(path, path1)
                    line.sendMessage(to, "Success change Video Profile")
            elif msg.contentType == 16: # Content type is album/note
                if settings['checkPost']:
                    if msg.contentMetadata['serviceType'] in ['GB', 'NT', 'MH']:
                        if msg.contentMetadata['serviceType'] in ['GB', 'NT']:
                            contact = line.getContact(sender)
                            author = contact.displayName
                        else:
                            author = msg.contentMetadata['serviceName']
                        posturl = msg.contentMetadata['postEndUrl']
                        res = 'Details Post'
                        res += '\n Creator : @!'
                        res += '\n Post Link : ' + posturl
                        line.sendMessage(to,res,[contact.mid])
            elif msg.contentType == 13: # Content type is contact
                if settings['checkContact']:
                    mid = msg.contentMetadata['mid']
                    try:
                        contact = line.getContact(mid)
                    except:
                        return line.sendMessage(to, 'Failed get details contact with mid ' + mid)
                    res = 'Details Contact'
                    res += '\n MID : ' + mid
                    res += '\n Display Name : ' + str(contact.displayName)
                    if contact.displayNameOverridden: res += '\n Display Name Overridden : ' + str(contact.displayNameOverridden)
                    res += '\n Status Message : ' + str(contact.statusMessage)
                    if contact.pictureStatus:
                        line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + contact.pictureStatus)
                    cover = line.getProfileCoverURL(mid)
                    line.sendImageWithURL(to, str(cover))
                    line.sendMessage(to, parsingRes(res))
                if settings['detectcontact']:
                  if msg._from in myMid:
                    mid = msg.contentMetadata['mid']
                    try:
                        contact = line.getContact(mid)
                    except:
                        return line.sendMessage(to, 'Failed get detected contact with mid ' + mid)
                    contact = []
                    if len(contact) >= 3:
                        try:
                            G = line.getGroup(msg.to)
                            line.sendMessage(to, "Dasar Kicker")
                            line.kickoutFromGroup(msg.to,[sender])
                        except:pass
                if settings['invitekontak']:
                    mid = msg.contentMetadata['mid']
                    try:
                        G = line.getGroup(to)
                        contact = line.getContact(mid)
                        line.findAndAddContactsByMid(mid)
                        line.inviteIntoGroup(to, [mid])
                        settings["invitekontak"] = False
                    except:
                        return line.sendMessage(to, 'Failed Invite contact with mid ' + mid)
                    else:
                            line.sendReplyMentionV2(msg.id, to,'Type: Invite Contact♪\n • Status: Success Invite @!',[mid])
                if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        line.sendMessage(to,"「 Blacklist 」\nContact Already In Blacklist -_-")
                        wait["wblacklist"] = False
                    else:
                        settings["blacklist"].append(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Blacklist 」\nSuccess Add Contact To Blacklist ^_^")
                        wait["wblacklist"] = False
                if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        settings["blacklist"].remove(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Blacklist 」\nSuccess Delete Contact From Blacklist ^_^")
                        wait["dblacklist"] = False
                    else:
                        wait["dblacklist"] = False
                        line.sendMessage(to,"「 Blacklist 」\nContact Not In Blacklist -_-")
                if wait["wwhitelist"] == True:
                    if msg.contentMetadata["mid"] in settings["whitelist"]:
                        line.sendMessage(to,"「 Whitelist 」\nContact Already In Whitelist -_-")
                        wait["wwhitelist"] = False
                    else:
                        settings["whitelist"].append(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Whitelist 」\nSuccess Add Contact To Whitelist ^_^")
                        wait["wwhitelist"] = False
                if wait["dwhitelist"] == True:
                    if msg.contentMetadata["mid"] in settings["whitelist"]:
                        settings["whitelist"].remove(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Whitelist 」\nSuccess Delete Contact From Whitelist ^_^")
                        wait["dwhitelist"] = False
                    else:
                        wait["dwhitelist"] = False
                        line.sendMessage(to,"「 Whitelist 」\nContact Not In Whitelist -_-")
                if wait["wteam"] == True:
                    if msg.contentMetadata["mid"] in settings["teamlist"]:
                        line.sendMessage(to,"「 Team 」\nContact Already In Team -_-")
                        wait["wteam"] = False
                    else:
                        settings["teamlist"].append(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Team 」\nSuccess Add Contact To Team ^_^")
                        wait["wteam"] = False
                if wait["dteam"] == True:
                    if msg.contentMetadata["mid"] in settings["teamlist"]:
                        settings["teamlist"].remove(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Team 」\nSuccess Delete Contact From Team ^_^")
                        wait["dteam"] = False
                    else:
                        wait["dteam"] = False
                        line.sendMessage(to,"「 Team 」\nContact Not In Team -_-")
                if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in settings["admin"]:
                        line.sendMessage(to,"「 Admin 」\nContact Already In Admin -_-")
                        wait["addadmin"] = False
                    else:
                        settings["admin"].append(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Admin 」\nSuccess Add Contact To Admin ^_^")
                        wait["addadmin"] = False
                if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in settings["admin"]:
                        settings["admin"].remove(msg.contentMetadata["mid"])
                        line.sendMessage(to,"「 Admin 」\nSuccess Delete Contact From Admin ^_^")
                        wait["delladmin"] = False
                    else:
                        wait["delladmin"] = False
                        line.sendMessage(to,"「 Admin 」\nContact Not In Admin -_-")
        if op.type == 65:
            if settings["unsendMessage"]:
                trop = op.param1
                msg_id = op.param2
                if msg_id in bool_dict:
                    if "text" in bool_dict[msg_id]:
                        trops = line.getContact(bool_dict[msg_id]["from"])
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        tro_ = "# Unsend Message"
                        tro_ += "\nSender : @!"
                        tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                        tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                        tro_ += "\nType : Text"
                        tro_ += "\nText : {}".format(bool_dict[msg_id]["text"])
                        line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                        del bool_dict[msg_id]
                    else:
                        if "image" in bool_dict[msg_id]:
                            trops = line.getContact(bool_dict[msg_id]["from"])
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            tro_ = "# Unsend Message"
                            tro_ += "\nSender : @!"
                            tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                            tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                            tro_ += "\nType : Image"
                            line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                            line.sendImage(trop, bool_dict[msg_id]["image"])
                            del bool_dict[msg_id]
                        else:
                            if "video" in bool_dict[msg_id]:
                                trops = line.getContact(bool_dict[msg_id]["from"])
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                tro_ = "# Unsend Message"
                                tro_ += "\nSender : @!"
                                tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                tro_ += "\nType : Video"
                                line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                line.sendVideo(trop, bool_dict[msg_id]["video"])
                                del bool_dict[msg_id]
                            else:
                                if "audio" in bool_dict[msg_id]:
                                        trops = line.getContact(bool_dict[msg_id]["from"])
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        tro_ = "# Unsend Message"
                                        tro_ += "\nSender : @!"
                                        tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                        tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                        tro_ += "\nType : Audio"
                                        line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                        line.sendAudio(trop, bool_dict[msg_id]["audio"])
                                        del bool_dict[msg_id]
                                else:
                                    if "sticker" in bool_dict[msg_id]:
                                            trops = line.getContact(bool_dict[msg_id]["from"])
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            tro_ = "# Unsend Message"
                                            tro_ += "\nSender : @!"
                                            tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                            tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                            tro_ += "\nType : Sticker"
                                            line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                            line.sendImageWithURL(trop, bool_dict[msg_id]["sticker"])
                                            del bool_dict[msg_id]
                                    else:
                                        if "mid" in bool_dict[msg_id]:
                                                trops = line.getContact(bool_dict[msg_id]["from"])
                                                tro_ = "# Unsend Message"
                                                tro_ += "\nSender : @!"
                                                tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                                tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                                tro_ += "\nType : Contact"
                                                line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                                line.sendContact(trop, bool_dict[msg_id]["mid"])
                                                del bool_dict[msg_id]
                                        else:
                                            if "location" in bool_dict[msg_id]:
                                                    trops = line.getContact(bool_dict[msg_id]["from"])
                                                    tro_ = "# Unsend Message"
                                                    tro_ += "\nSender : @!"
                                                    #tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                                    #tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                                    tro_ += "\nType : Location"
                                                    line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                                    line.sendLocation(trop, bool_dict[msg_id]["location"])
                                                    del bool_dict[msg_id]
                                            else:
                                                if "file" in bool_dict[msg_id]:
                                                        trops = line.getContact(bool_dict[msg_id]["from"])
                                                        tro_ = "# Unsend Message"
                                                        tro_ += "\nSender : @!"
                                                        tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                                        tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                                        tro_ += "\nType : File"
                                                        line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                                        line.sendFile(trop, bool_dict[msg_id]["file"])
        elif op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            if settings['autoRead']:
                line.sendChatChecked(to, msg_id)
            if msg.contentType == 0:
                if msg.toType != 0 and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if myMid in mention["M"]:
                                if line.getProfile().mid in mention["M"]:
                                    if to not in tagme['ROM']:
                                        tagme['ROM'][to] = {}
                                    if sender not in tagme['ROM'][to]:
                                        tagme['ROM'][to][sender] = {}
                                    if 'msg.id' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['msg.id'] = []
                                    if 'waktu' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['waktu'] = []
                                    tagme['ROM'][to][sender]['msg.id'].append(msg.id)
                                    tagme['ROM'][to][sender]['waktu'].append(msg.createdTime)
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                      if wait["Mentiongift"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                             if mention ['M'] in myMid:
                                idth = ["a0768339-c2d3-4189-9653-2909e9bb6f58","ec4a14ea-7437-407b-aee7-96b1cbbc1b4b","f35bd31f-5ec7-4b2f-b659-92adf5e3d151","ba1d5150-3b5f-4768-9197-01a3f971aa34","2b4ccc45-7309-47fe-a006-1a1edb846ddb","168d03c3-dbc2-456f-b982-3d6f85f52af2","d4f09a5f-29df-48ac-bca6-a204121ea165","517174f2-1545-43b9-a28f-5777154045a6","762ecc71-7f71-4900-91c9-4b3f213d8b26","2df50b22-112d-4f21-b856-f88df2193f9e"]
                                plihth = random.choice(idth)
                                jenis = ["5","6","7","8"]
                                plihjenis = random.choice(jenis)
                                line.sendMessage(msg.to, "Yang suka ngetag minta di gift yaa!?\nCek di chat, udah aku gift tuh...")
                                line.sendMessage(msg._from, None, contentMetadata={"PRDID":plihth,"PRDTYPE":"THEME","MSGTPL":plihjenis}, contentType=9)
                                break
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        if msg._from not in myMid:
                            if settings["mentionkick"] == True:
                                name = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    if myMid in mention["M"]:
                                        if line.getProfile().mid in mention["M"]:
                                            sendMention(to,"siapa lu ? @!", [msg._from])
                                            line.kickoutReplyFromGroup(msg.id,to, [msg._from])
                                            break
                if settings["unsendMessage"]:
                	try:
                	    bool_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 1: # Content type is image
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"image":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 2: #content type video
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"video":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 3:
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"audio":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            if msg.contentType == 6:
                  if wait["notifcall"] == True:
                    if msg._from not in myMid:
                        try:
                            contact = line.getContact(sender)
                            group = line.getGroup(msg.to)
                            cover = line.getProfileCoverURL(sender)
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            if msg.toType == 2:
                                b = msg.contentMetadata['GC_EVT_TYPE']
                                c = msg.contentMetadata["GC_MEDIA_TYPE"]
                                if c == 'AUDIO' and b == "S":
                                    arg = "• ᴄᴀʟʟ ᴀᴜᴅɪᴏ"
                                    arg += "\n• ᴛʏᴘᴇ {} ᴄᴀʟʟ".format(c) 
                                    arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                    arg += "\n• ɢᴄ: {}".format(str(group.name))
                                    arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                    arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                    arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    line.sendMessage(msg.to,arg)
                                if c == 'VIDEO' and b == "S":
                                    arg = "• ᴄᴀʟʟ ᴠɪᴅᴇᴏ"
                                    arg += "\n• ᴛʏᴘᴇ {} ᴄᴀʟʟ".format(c) 
                                    arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                    arg += "\n• ɢᴄ: {}".format(str(group.name))
                                    arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                    arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                    arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    line.sendMessage(msg.to,arg)
                                if c == 'LIVE' and b == "S":
                                    arg = "• ᴄᴀʟʟ ʟɪᴠᴇ"
                                    arg += "\n• ᴛʏᴘᴇ {} ᴄᴀʟʟ".format(c) 
                                    arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                    arg += "\n• ɢᴄ: {}".format(str(group.name))
                                    arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                    arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                    arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    line.sendMessage(msg.to,arg)
                                else:
                                    mills = int(msg.contentMetadata["DURATION"])
                                    seconds = (mills/1000)%60
                                    if c == "AUDIO" and b == "E":
                                        arg = "• ᴄᴀʟʟ ᴀᴜᴅɪᴏ"
                                        arg += "\n• ᴅɪᴀᴋʜɪʀɪ {} ᴄᴀʟʟ".format(c)
                                        arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                        arg += "\n• ɢᴄ: {}".format(str(group.name))
                                        arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                        arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                        arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                        arg += "\n• ᴅʀ: {}".format(seconds)
                                        line.sendMessage(msg.to,arg)
                                    if c == "VIDEO" and b == "E":
                                        arg = "• ᴄᴀʟʟ ᴠɪᴅᴇᴏ"
                                        arg += "\n• ᴅɪᴀᴋʜɪʀɪ {} ᴄᴀʟʟ".format(c)
                                        arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                        arg += "\n• ɢᴄ: {}".format(str(group.name))
                                        arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                        arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                        arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                        arg += "\n• ᴅʀ: {}".format(seconds)
                                        line.sendMessage(msg.to,arg)
                                    if c == "LIVE" and b == "E":
                                        arg = "• ᴄᴀʟʟ ʟɪᴠᴇ"
                                        arg += "\n• ᴅɪᴀᴋʜɪʀɪ {} ᴄᴀʟʟ".format(c)
                                        arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                        arg += "\n• ɢᴄ: {}".format(str(group.name))
                                        arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                        arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                        arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                        arg += "\n• ᴅʀ: {}".format(seconds)
                                        line.sendMessage(msg.to,arg)
                        except Exception as error:
                            print (error)
            elif msg.contentType == 7: # Content type is sticker
                if settings["unsendMessage"]:
                	try:
                	    sticker = msg.contentMetadata["STKID"]
                	    link = "http://dl.stickershop.line.naver.jp/stickershop/v1/sticker/{}/android/sticker.png".format(sticker)
                	    bool_dict[msg.id] = {"from":msg._from,"sticker":link,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 13: # Content type is contact
                if settings["unsendMessage"]:
                	try:
                	    mid = msg.contentMetadata["mid"]
                	    bool_dict[msg.id] = {"from":msg._from,"mid":mid,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 14: #Type file
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"file":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 16:
                    if wait["Timeline"] == True:
                            ret_ = "「 ᴅᴇᴛᴀɪʟ ᴘᴏsᴛɪɴɢᴀɴ 」"
                            if msg.contentMetadata["serviceType"] == "GB":
                                contact = line.getContact(sender)
                                auth = "\n• ˢᵏℹ༓ᴘᴇɴᴜʟɪs : {}".format(str(contact.displayName))
                            else:
                                auth = "\n• ˢᵏℹ ༓ᴘᴇɴᴜʟɪs : {}".format(str(msg.contentMetadata["serviceName"]))
                            ret_ += auth
                            if "stickerId" in msg.contentMetadata:
                                stck = "\n• ˢᵏℹ༓sᴛɪᴄᴋᴇʀ : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                ret_ += stck
                            if "mediaOid" in msg.contentMetadata:
                                object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                if msg.contentMetadata["mediaType"] == "V":
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• ˢᵏℹ༓ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        murl = "\n• ˢᵏℹ༓Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• ˢᵏℹ༓Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        murl = "\n• ˢᵏℹ༓Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                    ret_ += murl
                                else:
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• ˢᵏℹ༓Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• ˢᵏℹ༓Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                ret_ += ourl
                            if "text" in msg.contentMetadata:
                                text = "\n• ˢᵏℹ༓Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                purl = "\n• ˢᵏℹ༓Post URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += purl
                                ret_ += text
                                url = msg.contentMetadata['postEndUrl']
                            line.sendMessage(to, str(ret_))
                            line.likePost(purl[25:58], purl[66:], likeType=1005)
                            line.createComment(purl[25:58], purl[66:], wait["comment"])
            elif msg.contentType == 15: #Type location
                if settings["unsendMessage"]:
                	try:
                	    if msg.location != None:
                	        bool_dict[msg.id] = {"location":msg.location,"from":msg._from,"createdTime":msg.createdTime}
                	    else:
                	        bool_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            if msg.contentType == 0: # Content type is text
                if settings['mimic']['status']:
                    if sender in settings['mimic']['target'] and settings['mimic']['target'][sender]:
                        try:
                            line.sendMessage(to, text, msg.contentMetadata)
                            tmp_text.append(text)
                        except:
                            pass
                if settings['autoRespondMention']['status']:
                    if msg.toType in [1, 2] and 'MENTION' in msg.contentMetadata.keys() and sender != myMid and msg.contentType not in [6, 7, 9]:
                        mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = [mention['M'] for mention in mentions['MENTIONEES']]
                        if myMid in mentionees:
                            if line.getProfile().displayName in text:
                                if '@!' not in settings['autoRespondMention']['message']:
                                    line.sendMessage(to, settings['autoRespondMention']['message'])
                                else:
                                    line.sendMentionV2(to, settings['autoRespondMention']['message'], [sender])
                                line.sendMessage(to, None, contentMetadata={"STKID":"52002747","STKPKGID":"11537","STKVER":"1"},contentType=7)
                if settings['autoRespond']['status']:
                    if msg.toType == 0:
                        contact = line.getContact(sender)
                        if contact.attributes != 32 and 'MENTION' not in msg.contentMetadata.keys():
                            if '@!' not in settings['autoRespond']['message']:
                                line.sendMessage(to, settings['autoRespond']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoRespond']['message'], [sender])
    except TalkException as talk_error:
        logError(talk_error)
        if talk_error.code in [7, 8, 20]:
            sys.exit(1)
    except KeyboardInterrupt:
        sys.exit('##---- KEYBOARD INTERRUPT -----##')
    except Exception as error:
        logError(error)
def runningProgram():
    if settings['restartPoint'] is not None:
        try:
            line.sendMessage(settings['restartPoint'], 'Bot can operate again ♪')
        except TalkException:
            pass
        settings['restartPoint'] = None
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
        except TalkException as talk_error:
            logError(talk_error)
            if talk_error.code in [7, 8, 20]:
                sys.exit(1)
            continue
        except KeyboardInterrupt:
            sys.exit('##---- KEYBOARD INTERRUPT -----##')
        except Exception as error:
            logError(error)
            continue
        if ops:
            for op in ops:
                executeOp(op)
                oepoll.setRevision(op.revision)
if __name__ == '__main__':
    print ('##---- RUNNING PROGRAM -----##')
    runningProgram()
